﻿# =====================================================================
#  SETTING MP3 V1 - Tweaks (CPU, Input, Network, Power, Timer, Tools)
# =====================================================================

# ---------- ASSET FINDER (search app folder, else ask user) ----------
function Find-Asset([string[]]$Patterns, [string]$Title, [string]$Filter) {
    foreach ($p in $Patterns) {
        $f = Get-ChildItem -Path $ScriptRoot -Recurse -Filter $p -File -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($f) { return $f.FullName }
    }
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Title = $Title; $dlg.Filter = $Filter; $dlg.InitialDirectory = $ScriptRoot
    if ($dlg.ShowDialog($script:Form) -eq 'OK') { return $dlg.FileName }
    return $null
}

# ---------- CPU / PRIORITY ----------
$PriorityKey = 'HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl'
function Set-Priority([int]$Value) {
    Set-Reg $PriorityKey 'Win32PrioritySeparation' $Value
    Log ("Win32PrioritySeparation = 0x{0:X2}" -f $Value) 'ok'
}

$IFEO = 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options'
$PriorityMap = [ordered]@{
    'High'         = @{ Class = 'High';        Cpu = 3 }
    'Above Normal' = @{ Class = 'AboveNormal'; Cpu = 6 }
    'Normal'       = @{ Class = 'Normal';      Cpu = 2 }
    'Below Normal' = @{ Class = 'BelowNormal'; Cpu = 5 }
    'Idle'         = @{ Class = 'Idle';        Cpu = 1 }
    'Realtime'     = @{ Class = 'RealTime';    Cpu = 3 }   # IFEO has no realtime -> High
}
function Get-ExeName([string]$Exe) {
    $Exe = [IO.Path]::GetFileName($Exe.Trim())
    if ($Exe -notmatch '\.exe$') { $Exe += '.exe' }
    return $Exe
}
function Set-AppPriorityNow([string]$Exe, [string]$Priority) {
    $exe = Get-ExeName $Exe
    $procs = @(Get-Process -Name ([IO.Path]::GetFileNameWithoutExtension($exe)) -ErrorAction SilentlyContinue)
    if (-not $procs.Count) { throw "ไม่พบโปรเซส $exe (เปิดเกมก่อนแล้วกดใหม่)" }
    foreach ($pr in $procs) { $pr.PriorityClass = $PriorityMap[$Priority].Class }
    Log "$exe -> $Priority  (ตอนนี้, $($procs.Count) process)" 'ok'
}
function Set-AppPriorityPerm([string]$Exe, [string]$Priority) {
    $exe = Get-ExeName $Exe
    if ($Priority -eq 'Realtime') { Log "Realtime ใช้แบบถาวรไม่ได้ -> ปรับเป็น High" 'warn' }
    Set-Reg "$IFEO\$exe\PerfOptions" 'CpuPriorityClass' $PriorityMap[$Priority].Cpu
    Log "$exe -> $Priority  (PERMANENT)" 'ok'
}
function Remove-AppPriorityPerm([string]$Exe) {
    $exe = Get-ExeName $Exe
    Remove-Reg "$IFEO\$exe\PerfOptions" 'CpuPriorityClass'
    Log "$exe : ลบ Priority ถาวรแล้ว" 'ok'
}

# ---------- INPUT ----------
function Set-QueueSize([string]$Svc, [string]$Name, [string]$Val) {
    $v = if ($Val -eq 'Default') { 100 } else { [int]$Val }
    Set-Reg "HKLM\SYSTEM\CurrentControlSet\Services\$Svc\Parameters" $Name $v
    Log "$Name = $v  (รีบูตเพื่อให้มีผล)" 'ok'
}
function Set-KbdQueue([string]$Val) { Set-QueueSize 'kbdclass' 'KeyboardDataQueueSize' $Val }
function Set-MouQueue([string]$Val) { Set-QueueSize 'mouclass' 'MouseDataQueueSize' $Val }

# ---------- QOS ----------
$QosApps = @('FiveM.exe', 'FiveM_GTAProcess.exe')
function Apply-QoS {
    Set-Reg 'HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\QoS' 'Do not use NLA' '1' 'String'
    Remove-QoS -Quiet
    $i = 0
    foreach ($app in $QosApps) {
        $i++
        New-NetQosPolicy -Name "MP3_FiveM_$i" -AppPathNameMatchCondition $app -IPProtocolMatchCondition Both `
            -DSCPAction 46 -NetworkProfile All -PolicyStore localhost -ErrorAction Stop | Out-Null
        Log "QoS: $app -> DSCP 46" 'ok'
    }
}
function Remove-QoS([switch]$Quiet) {
    Get-NetQosPolicy -PolicyStore localhost -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'MP3_*' } |
        ForEach-Object { Remove-NetQosPolicy -Name $_.Name -PolicyStore localhost -Confirm:$false -ErrorAction SilentlyContinue }
    if (-not $Quiet) { Log "QoS removed" 'ok' }
}
function Test-QoS {
    return [bool](Get-NetQosPolicy -PolicyStore localhost -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'MP3_*' })
}

# ---------- NETWORK ADAPTERS (registry, backed up) ----------
$NicClass = 'HKLM\SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}'
function Get-NicKeys([string]$Like = '*') {
    $guids = @{}
    Get-NetAdapter -Physical -ErrorAction SilentlyContinue | ForEach-Object { $guids[$_.InterfaceGuid.ToUpper()] = $_.Name }
    $res = @()
    $root = Open-RegKey $NicClass
    foreach ($sub in $root.GetSubKeyNames()) {
        if ($sub -notmatch '^\d{4}$') { continue }
        try { $k = $root.OpenSubKey($sub) } catch { continue }
        if (-not $k) { continue }
        $id = [string]$k.GetValue('NetCfgInstanceId'); $desc = [string]$k.GetValue('DriverDesc'); $k.Close()
        if ($id -and $guids.ContainsKey($id.ToUpper()) -and $desc -like $Like) {
            $res += [pscustomobject]@{ Path = "$NicClass\$sub"; Desc = $desc; Name = $guids[$id.ToUpper()]; Guid = $id }
        }
    }
    $root.Close()
    return $res
}
function Set-NicParam($Nic, [string]$Kw, $Val) {
    $k = Open-RegKey "$($Nic.Path)\Ndi\params\$Kw"
    $has = [bool]$k; if ($k) { $k.Close() }
    if (-not $has -and $null -eq (Get-Reg $Nic.Path $Kw)) { return $false }   # adapter has no such option
    Set-Reg $Nic.Path $Kw ([string]$Val) 'String'
    return $true
}
function Get-NicEnum($Nic, [string]$Kw) {
    $h = @{}
    $k = Open-RegKey "$($Nic.Path)\Ndi\params\$Kw\Enum"
    if ($k) { foreach ($n in $k.GetValueNames()) { $h[$n] = [string]$k.GetValue($n) }; $k.Close() }
    return $h
}
function Get-NicMax($Nic, [string]$Kw) {
    $k = Open-RegKey "$($Nic.Path)\Ndi\params\$Kw"
    if ($k) { try { return $k.GetValue('max') } finally { $k.Close() } }
}
function Restart-Nics($Nics) {
    foreach ($n in $Nics) {
        try { Restart-NetAdapter -Name $n.Name -Confirm:$false -ErrorAction Stop; Log "  restart adapter: $($n.Name)" }
        catch { Log "  ! restart $($n.Name): $($_.Exception.Message)" 'warn' }
    }
}

$NicPowerOff = @('*EEE','EEELinkAdvertisement','AdvancedEEE','EnableGreenEthernet','GigaLite','PowerSavingMode',
    'EnablePME','*WakeOnMagicPacket','*WakeOnPattern','WakeOnLink','WakeOnMagicPacketFromS5','S5WakeOnLan',
    '*ModernStandbyWoLMagicPacket','ULPMode','*SelectiveSuspend','AutoPowerSaveModeEnabled','*DeviceSleepOnDisconnect',
    'EnablePowerManagement','ReduceSpeedOnPowerDown','EnableDynamicPowerGating','EnableConnectedPowerGating','AutoDisableGigabit')

function Apply-NetworkTweaks {
    $nics = @(Get-NicKeys)
    if (-not $nics.Count) { throw "ไม่พบการ์ดเครือข่าย" }
    foreach ($n in $nics) {
        $c = 0; foreach ($kw in $NicPowerOff) { if (Set-NicParam $n $kw 0) { $c++ } }
        Set-Reg $n.Path 'PnPCapabilities' 24
        $if = "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\$($n.Guid)"
        Set-Reg $if 'TcpAckFrequency' 1; Set-Reg $if 'TCPNoDelay' 1; Set-Reg $if 'TcpDelAckTicks' 0
        Log "  $($n.Desc): power saving / EEE / WoL off ($c), Nagle off" 'ok'
    }
    Exec 'netsh int tcp set heuristics disabled'
    Exec 'netsh int tcp set global ecncapability=disabled'
    Exec 'netsh int tcp set global timestamps=disabled'
    Exec 'netsh int tcp set global rsc=disabled'
    Exec 'netsh int tcp set global nonsackrttresiliency=disabled'
    Exec 'netsh int tcp set global initialRto=2000'
    Exec 'netsh int tcp set supplemental template=internet congestionprovider=ctcp' -Quiet
    $script:State['NetTweaked'] = $true; Save-State
    Restart-Nics $nics
}

$RealtekOff = @('*InterruptModeration','*RSS','*FlowControl','*LsoV1IPv4','*LsoV2IPv4','*LsoV2IPv6',
    '*IPChecksumOffloadIPv4','*TCPChecksumOffloadIPv4','*TCPChecksumOffloadIPv6','*UDPChecksumOffloadIPv4',
    '*UDPChecksumOffloadIPv6','*PMARPOffload','*PMNSOffload','*RscIPv4','*RscIPv6') + $NicPowerOff

function Apply-InternetReg {
    $nics = @(Get-NicKeys '*Realtek*')
    if (-not $nics.Count) { throw "ไม่พบการ์ดเน็ต Realtek" }
    foreach ($n in $nics) {
        Log "  Realtek: $($n.Desc)"
        $c = 0; foreach ($kw in $RealtekOff) { if (Set-NicParam $n $kw 0) { $c++ } }
        Log "    offload / IM / RSS / EEE / power saving off ($c)" 'ok'
        $sp = (Get-NicEnum $n '*SpeedDuplex').GetEnumerator() | Where-Object { $_.Value -match '2\.5\s*G' } | Select-Object -First 1
        if ($sp) { Set-NicParam $n '*SpeedDuplex' $sp.Name | Out-Null; Log "    SpeedDuplex = $($sp.Value)" 'ok' }
        else { Log "    การ์ดนี้ไม่รองรับ 2.5G -> คง Auto Negotiation" 'warn' }
        foreach ($b in '*ReceiveBuffers', '*TransmitBuffers') {
            $m = Get-NicMax $n $b
            if ($m) { Set-NicParam $n $b $m | Out-Null; Log "    $b = $m" 'ok' }
        }
    }
    $script:State['NetTweaked'] = $true; Save-State
    Restart-Nics $nics
}

function Install-NetDriver {
    $f = Find-Asset @('Install_*.exe') 'เลือกตัวติดตั้งไดรเวอร์เน็ต (Install_*.exe)' 'Installer (*.exe)|*.exe'
    if (-not $f) { throw "ยกเลิก - ไม่ได้เลือกไฟล์" }
    Start-Process -FilePath $f
    Log "เปิดตัวติดตั้ง: $f" 'ok'
}

# ---------- POWER ----------
$HighPerfGuid = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'
$BalancedGuid = '381b4222-f694-41f0-9685-ff5bb260df2e'
function Get-ActiveScheme {
    $o = (& powercfg /getactivescheme) -join ' '
    if ($o -match '([0-9a-fA-F\-]{36})\s+\((.+)\)') { return [pscustomobject]@{ Guid = $Matches[1]; Name = $Matches[2].Trim() } }
    return [pscustomobject]@{ Guid = $null; Name = 'N/A' }
}
function Save-PowerScheme {
    if (-not $script:State.Contains('PowerScheme')) { $script:State['PowerScheme'] = (Get-ActiveScheme).Guid; Save-State }
}
function Import-Mp3Pow {
    $f = Find-Asset @('MP3*.pow', '*.pow') 'เลือกไฟล์ Power Plan (.pow)' 'Power plan (*.pow)|*.pow'
    if (-not $f) { throw "ยกเลิก - ไม่ได้เลือกไฟล์ .pow" }
    Save-PowerScheme
    $g = [guid]::NewGuid().ToString()
    Exec "powercfg -import `"$f`" $g"
    Exec "powercfg -changename $g `"MP3 STEPLNW`""
    Exec "powercfg -setactive $g"
    $script:State['ImportedPlans'] = @(@($script:State['ImportedPlans']) | Where-Object { $_ }) + $g; Save-State
    Log "Power plan: MP3 STEPLNW ($g)" 'ok'
}
function Set-PowHigh {
    Save-PowerScheme
    if (((& powercfg /list) -join ' ') -notmatch $HighPerfGuid) { Exec "powercfg -duplicatescheme $HighPerfGuid $HighPerfGuid" }
    Exec "powercfg -setactive $HighPerfGuid"
    Log "Power plan: High performance" 'ok'
}
function Set-PowBalanced {
    Exec "powercfg -setactive $BalancedGuid"
    Log "Power plan: Balanced" 'ok'
}

# ---------- MP3 GAMING POWER PLAN (built in, one click) ----------
$UltimateGuid = 'e9a42b02-d5df-448d-aa00-03f14749eb61'
$Mp3PlanGuid  = '5f0d3a3e-8b1c-4c5e-9a6d-6d50cc0a3001'   # fixed id -> re-applying updates the same plan

# [subgroup, setting, AC value, DC value, label]   (DC = on battery, kept sane for laptops)
$Mp3PlanSettings = @(
    # CPU: full clocks, aggressive boost, no core parking, react instantly
    @('SUB_PROCESSOR', 'PROCTHROTTLEMIN',  100, 100, 'CPU min state 100%'),
    @('SUB_PROCESSOR', 'PROCTHROTTLEMAX',  100, 100, 'CPU max state 100%'),
    @('SUB_PROCESSOR', 'PERFBOOSTMODE',      2,   2, 'Boost mode: Aggressive'),
    @('SUB_PROCESSOR', 'PERFEPP',            0,  25, 'Energy preference: max performance'),
    @('SUB_PROCESSOR', 'CPMINCORES',       100, 100, 'Core parking off'),
    @('SUB_PROCESSOR', 'CPMAXCORES',       100, 100, 'All cores unparked'),
    @('SUB_PROCESSOR', 'PERFINCTHRESHOLD',  10,  10, 'Clock up fast'),
    @('SUB_PROCESSOR', 'PERFDECTHRESHOLD',   8,   8, 'Clock down slow'),
    @('SUB_PROCESSOR', 'PERFINCPOL',         2,   2, 'Increase policy: Rocket'),
    @('SUB_PROCESSOR', 'PERFDECPOL',         1,   1, 'Decrease policy: Single'),
    @('SUB_PROCESSOR', 'PERFCHECK',         15,  30, 'Perf check 15 ms'),
    # devices that cause input / frame delay when they wake up
    @('SUB_PCIEXPRESS', 'ASPM',              0,   0, 'PCIe Link State PM off'),
    @('2a737441-1930-4402-8d77-b2bebba308a3', '48e6b7a6-50f5-4782-a5d4-53bb8f07e226', 0, 0, 'USB selective suspend off'),
    @('2a737441-1930-4402-8d77-b2bebba308a3', '0853a681-27c8-4100-a2fd-82013e970683', 0, 0, 'USB hub timeout off'),
    @('19cbb8fa-5279-450e-9fac-8a3d5fedd0c1', '12bbebe6-58d6-4636-95bb-3217ef867c1a', 0, 0, 'Wi-Fi max performance'),
    @('SUB_DISK', 'DISKIDLE',                0,   0, 'Disk never sleeps'),
    # never sleep / hibernate while plugged in
    @('SUB_SLEEP', 'STANDBYIDLE',            0, 900, 'Sleep: never (AC)'),
    @('SUB_SLEEP', 'HIBERNATEIDLE',          0,   0, 'Hibernate: never'),
    @('SUB_SLEEP', 'HYBRIDSLEEP',            0,   0, 'Hybrid sleep off')
)

function Install-Mp3PowerPlan {
    Save-PowerScheme
    $list = (& powercfg /list) -join ' '
    if ($list -notmatch $Mp3PlanGuid) {
        # base = Ultimate Performance (hidden on most PCs), fallback High performance
        $null = & cmd.exe /c "powercfg -duplicatescheme $UltimateGuid $Mp3PlanGuid 2>&1"
        if (((& powercfg /list) -join ' ') -notmatch $Mp3PlanGuid) {
            $null = & cmd.exe /c "powercfg -duplicatescheme $HighPerfGuid $Mp3PlanGuid 2>&1"
        }
        if (((& powercfg /list) -join ' ') -notmatch $Mp3PlanGuid) { throw "สร้าง Power Plan ไม่สำเร็จ" }
        $script:State['ImportedPlans'] = @(@($script:State['ImportedPlans']) | Where-Object { $_ -and $_ -ne $Mp3PlanGuid }) + $Mp3PlanGuid
        Save-State
    }
    Exec "powercfg -changename $Mp3PlanGuid `"MP3 STEPLNW Gaming`" `"FiveM low latency - by SETTING MP3 V1`""
    $ok = 0
    foreach ($s in $Mp3PlanSettings) {
        $null = & cmd.exe /c "powercfg -setacvalueindex $Mp3PlanGuid $($s[0]) $($s[1]) $($s[2]) 2>&1"; $a = $LASTEXITCODE
        $null = & cmd.exe /c "powercfg -setdcvalueindex $Mp3PlanGuid $($s[0]) $($s[1]) $($s[3]) 2>&1"
        if ($a -eq 0) { $ok++ } else { Log "  - skip (ไม่มีในเครื่องนี้): $($s[4])" 'info' }
    }
    Exec "powercfg -setactive $Mp3PlanGuid"
    Log "Power plan: MP3 STEPLNW Gaming  ($ok/$($Mp3PlanSettings.Count) ค่า)" 'ok'
}

# ---------- TIMER RESOLUTION (0.5 ms, auto-start task) ----------
$TimerTask   = 'MP3_TimerResolution'
$TimerScript = Join-Path $AppDir 'TimerRes.ps1'
function Install-TimerRes {
    @'
Add-Type @"
using System; using System.Runtime.InteropServices;
public static class TR { [DllImport("ntdll.dll")] public static extern int NtSetTimerResolution(uint d, bool s, out uint c); }
"@
$c = 0; [TR]::NtSetTimerResolution(5000, $true, [ref]$c) | Out-Null
while ($true) { Start-Sleep -Seconds 3600 }
'@ | Set-Content -Path $TimerScript -Encoding UTF8
    Set-Reg 'HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel' 'GlobalTimerResolutionRequests' 1
    $act = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$TimerScript`""
    $trg = New-ScheduledTaskTrigger -AtStartup
    $pri = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    $set = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero)
    Register-ScheduledTask -TaskName $TimerTask -Action $act -Trigger $trg -Principal $pri -Settings $set -Force | Out-Null
    Start-ScheduledTask -TaskName $TimerTask
    Log "Timer Resolution 0.5ms : ON (เริ่มอัตโนมัติทุกครั้งที่เปิดเครื่อง)" 'ok'
}
function Remove-TimerRes {
    if (Get-ScheduledTask -TaskName $TimerTask -ErrorAction SilentlyContinue) {
        Stop-ScheduledTask -TaskName $TimerTask -ErrorAction SilentlyContinue
        Unregister-ScheduledTask -TaskName $TimerTask -Confirm:$false
    }
    Remove-Reg 'HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel' 'GlobalTimerResolutionRequests'
    Log "Timer Resolution : DEFAULT" 'ok'
}
function Test-TimerRes { return [bool](Get-ScheduledTask -TaskName $TimerTask -ErrorAction SilentlyContinue) }

# ---------- TOOLS ----------
function Import-NvidiaProfile {
    $insp = Find-Asset @('nvidiaProfileInspector.exe') 'เลือก nvidiaProfileInspector.exe' 'nvidiaProfileInspector.exe|nvidiaProfileInspector.exe|Program (*.exe)|*.exe'
    if (-not $insp) { throw "ยกเลิก - ไม่พบ nvidiaProfileInspector.exe" }
    $nip = Find-Asset @('MP3.nip', '*.nip') 'เลือกไฟล์โปรไฟล์ NVIDIA (.nip)' 'NVIDIA profile (*.nip)|*.nip'
    if (-not $nip) { throw "ยกเลิก - ไม่ได้เลือกไฟล์ .nip" }
    Start-Process -FilePath $insp -ArgumentList "-silentImport `"$nip`"" -Wait -WindowStyle Hidden
    Log "NVIDIA profile imported: $(Split-Path $nip -Leaf)" 'ok'
}
