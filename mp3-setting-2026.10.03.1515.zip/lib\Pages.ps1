﻿# =====================================================================
#  SETTING MP3 V1 - Pages
#  Grid: left x=4, right x=452, half card w=432 (inner x=22, w=388), full w=880 (inner right edge 858)
#  Card rule: title -> description at y=52 -> buttons anchored to bottom (bottom padding 28 incl. shadow)
#             full-width cards: text left, button right & vertically centered
#  Rows are 16px apart.
# =====================================================================

# ---------- DASHBOARD ----------
$pgHome = New-Page "home"
New-PageTitle $pgHome "Dashboard" "ภาพรวมระบบ และการตั้งค่าด่วน"

$hero = New-Object Mp3UI.Hero
$hero.Bounds = New-Object System.Drawing.Rectangle(4, 80, 880, 158)
$pgHome.Controls.Add($hero)

$cSys = New-Card $pgHome 4 254 432 214 "SYSTEM"
$si = Get-SysInfo
$y = 54
foreach ($row in @(@('CPU', $si.CPU), @('GPU', $si.GPU), @('RAM', $si.RAM), @('OS', $si.OS))) {
    New-Lbl $cSys $row[0] 22 $y -Muted | Out-Null
    New-Lbl $cSys $row[1] 74 $y | Out-Null
    $y += 34
}

$cQuick = New-Card $pgHome 452 254 432 214 "QUICK APPLY"
New-Lbl $cQuick "กดครั้งเดียว: CPU + FiveM + Input + QoS + Network + Power + Timer" 22 52 -Muted | Out-Null
$bQuick = New-Btn $cQuick "APPLY ALL  (PERSISTENT)" 22 134 388 52 -Accent -Glyph ([char]0xE945)
On-Click $bQuick "APPLY ALL" { Apply-AllPersistent } "จะปรับ CPU, FiveM Priority, Input, QoS, Power, Timer, Latency และ Network (การ์ดเน็ตจะรีสตาร์ทชั่วครู่)`n`nทุกค่าถูก backup อัตโนมัติ กู้คืนได้ที่หน้า Restore"

$cBoost = New-Card $pgHome 4 484 880 206 "MP3 BOOST"
New-Lbl $cBoost "GPU / Multimedia / Input / Network / CPU Power / Timer / Telemetry / GameDVR / Visual / Background Apps  -  10 หมวดในคลิกเดียว" 22 52 -Muted | Out-Null
$bSet = New-Btn $cBoost "SETTING MP3" 22 92 410 56 -Accent -Glyph ([char]0xE945)
On-Click $bSet "SETTING MP3" { Invoke-SettingMp3 } "ติดตั้งชุด SETTING MP3 ทั้ง 10 หมวด`n(ปิด BITS / DiagTrack / Defender policy, ล็อก CPU idle, ปรับ bcdedit)`n`nแนะนำให้รีสตาร์ทเครื่องหลังทำ"
$bFix = New-Btn $cBoost "FIX CPU 100%" 448 92 410 56 -Glyph ([char]0xE90F)
On-Click $bFix "FIX CPU 100%" { Invoke-FixCpu } "รีเซ็ตค่าที่ทำให้ CPU โชว์ 100% (CPU Idle, Prefetch, Memory, BCD timing)?"
$fixNote = New-Lbl $cBoost "( แนะนำให้รันหลังจาก รัน SETTING MP3 แล้ว )" 448 158 -Red
$fixNote.Left = 448 + [int]((410 - $fixNote.Width) / 2)          # centered under FIX CPU

$cStat = New-Card $pgHome 4 706 880 120 "STATUS"
$chips = @()
foreach ($i in 1..4) {
    $ch = New-Object Mp3UI.StatusChip
    $ch.Location = New-Object System.Drawing.Point(22, 58)
    $cStat.Controls.Add($ch); $chips += $ch
}
$bRef = New-Btn $cStat "REFRESH" 718 54 140 40 -Glyph ([char]0xE72C)
$bRef.Add_Click({ Update-Status; Toast "อัปเดตสถานะแล้ว" 'info' })

# ---------- CPU / PRIORITY ----------
$pgCpu = New-Page "cpu"
New-PageTitle $pgCpu "CPU / Priority" "Win32PrioritySeparation และ Priority ของแอป"

$cWps = New-Card $pgCpu 4 80 432 314 "WIN32 PRIORITY SEPARATION"
New-Lbl $cWps "0x26 = Short / Variable / High foreground boost" 22 52 -Muted | Out-Null
New-Lbl $cWps "ค่าปัจจุบัน" 22 96 -Muted | Out-Null
$lblWpsNow = New-Lbl $cWps "--" 20 116 -Bold -Size 24
$lblWpsNow.ForeColor = [Mp3UI.Theme]::Accent
$b = New-Btn $cWps "MP3  (0x26)" 22 182 388 46 -Accent -Glyph ([char]0xE945)
On-Click $b "Win32Priority MP3" { Set-Priority 0x26 }
$b = New-Btn $cWps "DEFAULT  (0x02)" 22 240 388 46
On-Click $b "Win32Priority Default" { Set-Priority 0x02 }

$cApp = New-Card $pgCpu 452 80 432 314 "APP PRIORITY"
New-Lbl $cApp "PERMANENT = มีผลทุกครั้งที่เปิดเกม (Realtime จะถูกปรับเป็น High)" 22 52 -Muted | Out-Null
New-Lbl $cApp "App (.exe)" 22 86 -Muted | Out-Null
$tbExe = New-Object Mp3UI.ModernTextBox
$tbExe.Bounds = New-Object System.Drawing.Rectangle(22, 108, 388, 42)
$tbExe.Text = "FiveM_GTAProcess.exe"
$cApp.Controls.Add($tbExe)
New-Lbl $cApp "Priority" 22 160 -Muted | Out-Null
$cbP = New-Combo $cApp @("High","Above Normal","Normal","Below Normal","Idle","Realtime") 22 182 388 @("High","Above","Normal","Below","Idle","Realtime")
$b = New-Btn $cApp "SET NOW" 22 242 120 44
On-Click $b "Set Priority (now)" { Set-AppPriorityNow $tbExe.Text (Get-ComboValue $cbP) }
$b = New-Btn $cApp "PERMANENT" 150 242 132 44 -Accent
On-Click $b "Set Priority (permanent)" { Set-AppPriorityPerm $tbExe.Text (Get-ComboValue $cbP) }
$b = New-Btn $cApp "REMOVE" 290 242 120 44
On-Click $b "Remove Priority" { Remove-AppPriorityPerm $tbExe.Text }

# ---------- INPUT ----------
$pgIn = New-Page "input"
New-PageTitle $pgIn "Input" "Keyboard / Mouse Data Queue Size"

$cKbd = New-Card $pgIn 4 80 432 214 "KEYBOARD QUEUE"
New-Lbl $cKbd "ค่าน้อย = ดีเลย์ต่ำ (Default = 100)" 22 52 -Muted | Out-Null
$cbK = New-Combo $cKbd @("16","20","30","50","Default") 22 84 388
$b = New-Btn $cKbd "APPLY" 22 140 388 46 -Accent
On-Click $b "Keyboard Queue" { Set-KbdQueue (Get-ComboValue $cbK) }

$cMou = New-Card $pgIn 452 80 432 214 "MOUSE QUEUE"
New-Lbl $cMou "ค่าน้อย = ดีเลย์ต่ำ (Default = 100)" 22 52 -Muted | Out-Null
$cbM = New-Combo $cMou @("16","20","30","50","Default") 22 84 388
$b = New-Btn $cMou "APPLY" 22 140 388 46 -Accent
On-Click $b "Mouse Queue" { Set-MouQueue (Get-ComboValue $cbM) }

# ---------- NETWORK ----------
$pgNet = New-Page "net"
New-PageTitle $pgNet "Network" "QoS, NIC tweaks และค่า Internet (Realtek)"

$cQos = New-Card $pgNet 4 80 432 196 "QOS - FIVEM (DSCP 46)"
New-Lbl $cQos "FiveM.exe + FiveM_GTAProcess.exe  ->  DSCP 46 (EF)" 22 52 -Muted | Out-Null
$b = New-Btn $cQos "APPLY QoS" 22 122 188 46 -Accent
On-Click $b "Apply QoS" { Apply-QoS }
$b = New-Btn $cQos "REMOVE QoS" 222 122 188 46
On-Click $b "Remove QoS" { Remove-QoS }

$cNic = New-Card $pgNet 452 80 432 196 "NETWORK TWEAKS (NIC + TCP)"
New-Lbl $cNic "ปิด power saving / EEE / WoL + netsh TCP tweaks" 22 52 -Muted | Out-Null
$b = New-Btn $cNic "APPLY NETWORK TWEAKS" 22 122 388 46 -Accent
On-Click $b "Network Tweaks" { Apply-NetworkTweaks } "Apply NIC + TCP tweaks?`n(ควรติดตั้ง driver เน็ตก่อน / การ์ดเน็ตจะรีสตาร์ทชั่วครู่ / รีบูตหลังทำ)"

$cReg = New-Card $pgNet 4 292 432 196 "INTERNET (REALTEK ALL)"
New-Lbl $cReg "SpeedDuplex 2.5G (ถ้ารองรับ), IM off, RSS off, buffers max" 22 52 -Muted | Out-Null
$b = New-Btn $cReg "APPLY INTERNET VALUES" 22 122 388 46 -Accent
On-Click $b "Internet (Realtek)" { Apply-InternetReg } "Apply internet tweaks ไปที่ Realtek (ทุกรุ่น)?`n(ปิด offload/EEE/power saving + tune buffers, การ์ดเน็ตจะรีสตาร์ทชั่วครู่)"

$cDrv = New-Card $pgNet 452 292 432 196 "NETWORK DRIVER"
New-Lbl $cDrv "เปิดตัวติดตั้ง Install_*.exe (เลือกไฟล์เองได้ถ้าหาไม่เจอ)" 22 52 -Muted | Out-Null
$b = New-Btn $cDrv "INSTALL NETWORK DRIVER" 22 122 388 46 -Glyph ([char]0xE896)
On-Click $b "Install Network Driver" { Install-NetDriver }

# ---------- POWER / TIMER ----------
$pgPow = New-Page "power"
New-PageTitle $pgPow "Power / Timer" "Power plan และ Timer Resolution"

$cPow = New-Card $pgPow 4 80 432 280 "POWER PLAN"
New-Lbl $cPow "MP3 Gaming: CPU 100% ตลอด, Boost แรงสุด, ปิด Core parking / USB / PCIe sleep" 22 52 -Muted | Out-Null
$b = New-Btn $cPow "MP3 GAMING PLAN  (1 คลิก)" 22 98 388 52 -Accent -Glyph ([char]0xE945)
On-Click $b "MP3 Gaming Power Plan" { Install-Mp3PowerPlan }
$b = New-Btn $cPow "IMPORT .POW" 22 162 188 44
On-Click $b "Import Power Plan (.pow)" { Import-Mp3Pow }
$b = New-Btn $cPow "HIGH PERF" 222 162 188 44
On-Click $b "High Performance" { Set-PowHigh }
$b = New-Btn $cPow "BALANCED (DEFAULT)" 22 208 388 44
On-Click $b "Balanced" { Set-PowBalanced }

$cTim = New-Card $pgPow 452 80 432 280 "TIMER RESOLUTION"
New-Lbl $cTim "0.5 ms - เริ่มอัตโนมัติทุกครั้งที่เปิดเครื่อง" 22 52 -Muted | Out-Null
$b = New-Btn $cTim "ON  (RECOMMENDED)" 22 116 388 62 -Accent -Glyph ([char]0xE916)
On-Click $b "Timer Resolution ON" { Install-TimerRes }
$b = New-Btn $cTim "DEFAULT  (REMOVE)" 22 190 388 62
On-Click $b "Timer Resolution Default" { Remove-TimerRes }

# ---------- REGISTRY (.reg) ----------
$pgRegs = New-Page "reg"
New-PageTitle $pgRegs "Registry (.reg)" "ชุดค่า Registry สำเร็จรูป - ทุกค่าถูก backup อัตโนมัติ กู้คืนได้ที่หน้า Restore"

$cR1 = New-Card $pgRegs 4 80 432 262 "WINDOWS PRIVACY & GAMING"
New-Lbl $cR1 "ปิด Sync  ·  Transparency  ·  Game DVR`nปิด Telemetry  ·  Ads  ·  Background apps`nเปิด Game Mode + HAGS  ·  ปิด VRR / Ease of Access" 22 52 -Muted | Out-Null
$b = New-Btn $cR1 "APPLY" 22 134 388 46 -Accent -Glyph ([char]0xE943)
On-Click $b "Windows Privacy & Gaming" { Apply-RegWindows }
$b = New-Btn $cR1 "EXPORT .REG" 22 192 388 42 -Glyph ([char]0xE74E)
$b.Add_Click({ try { Export-RegFile $RegWindows 'MP3_Windows.reg' } catch { Log $_.Exception.Message 'warn' } })

$cR2 = New-Card $pgRegs 452 80 432 262 "LATENCY & UDP NETWORK"
New-Lbl $cR2 "ปิด Network Throttling`nSystemResponsiveness 0  ·  Frame latency 1`nAFD UDP send / receive buffers" 22 52 -Muted | Out-Null
$b = New-Btn $cR2 "APPLY" 22 134 388 46 -Accent -Glyph ([char]0xE943)
On-Click $b "Latency & UDP Network" { Apply-RegLatency }
$b = New-Btn $cR2 "EXPORT .REG" 22 192 388 42 -Glyph ([char]0xE74E)
$b.Add_Click({ try { Export-RegFile $RegLatency 'MP3_Latency.reg' } catch { Log $_.Exception.Message 'warn' } })

$cR3 = New-Card $pgRegs 4 358 880 112 "APPLY ALL .REG"
New-Lbl $cR3 "ใช้ทั้ง 2 ชุดพร้อมกันในคลิกเดียว" 22 52 -Muted -MaxW 560 | Out-Null
New-Lbl $cR3 "หมายเหตุ: SETTING MP3 จะตั้ง HwSchMode = 0 ทับค่า HAGS ของชุดนี้" 22 74 -Muted -Size 8.5 -MaxW 560 | Out-Null
$b = New-Btn $cR3 "APPLY BOTH" 618 29 240 48 -Accent -Glyph ([char]0xE8FB)
On-Click $b "Apply All .reg" { Apply-RegWindows; Apply-RegLatency }

# ---------- TOOLS ----------
$pgTools = New-Page "tools"
New-PageTitle $pgTools "Tools" "NVIDIA profile และอื่นๆ"

$cNv = New-Card $pgTools 4 80 432 196 "NVIDIA PROFILE"
New-Lbl $cNv "ต้องมี nvidiaProfileInspector.exe (เลือกไฟล์เองได้)" 22 52 -Muted | Out-Null
$b = New-Btn $cNv "IMPORT MP3.NIP" 22 122 388 46 -Accent
On-Click $b "Import NVIDIA Profile" { Import-NvidiaProfile }

$cLic = New-Card $pgTools 452 80 432 196 "LICENSE"
New-Lbl $cLic "HWID:  $(Get-HardwareID)" 22 52 -Muted | Out-Null
New-Lbl $cLic "License: ACTIVATED ✓" 22 78 -Bold | Out-Null
$b = New-Btn $cLic "COPY HWID" 22 122 180 46 -Glyph ([char]0xE8C8)
$b.Add_Click({ [System.Windows.Forms.Clipboard]::SetText((Get-HardwareID)); Log "HWID copied" 'ok'; Toast "คัดลอก HWID แล้ว" 'ok' })

$cSc = New-Card $pgTools 4 292 880 112 "SHORTCUTS"
New-Lbl $cSc "เปิดโฟลเดอร์ Backup และไฟล์ Log ของโปรแกรม" 22 52 -Muted -MaxW 360 | Out-Null
$b = New-Btn $cSc "OPEN BACKUP FOLDER" 398 29 248 48 -Glyph ([char]0xE8B7)
$b.Add_Click({ Start-Process explorer.exe $BackupDir })
$b = New-Btn $cSc "OPEN LOG FILE" 658 29 200 48 -Glyph ([char]0xE7C3)
$b.Add_Click({ if (Test-Path $LogFile) { Start-Process notepad.exe $LogFile } })

# ---------- RESTORE ----------
$pgRes = New-Page "restore"
New-PageTitle $pgRes "Restore" "ย้อนทุกการตั้งค่ากลับเป็นค่าดั้งเดิม (จาก backup อัตโนมัติ)"

$cRes = New-Card $pgRes 4 80 880 160 "RESET / RESTORE ALL"
New-Lbl $cRes "คืนค่า: CPU Priority, QoS, Input Queue, Timer, NIC, netsh, bcdedit, Power Plan, App Priority, .reg, SETTING MP3" 22 52 -Muted -MaxW 500 | Out-Null
New-Lbl $cRes "Backup อยู่ที่: $BackupDir" 22 100 -Muted -Size 8.5 -MaxW 500 | Out-Null
$b = New-Btn $cRes "RESTORE ALL SETTINGS" 558 49 300 56 -Danger -Glyph ([char]0xE777)
On-Click $b "Restore All" { Restore-All } "Restore ทุกอย่างกลับค่าดั้งเดิม?`n(การ์ดเน็ตอาจรีสตาร์ทชั่วครู่ และควรรีบูตเครื่องหลังทำ)" -Danger

# ---------- STATUS ----------
function Update-Status {
    try {
        $st = Get-Mp3Status
        $chips[0].Set("Win32", $st.Win32, 2)
        $chips[1].Set("QoS", $(if ($st.QoS) { 'ON' } else { 'OFF' }), [int]$st.QoS)
        $chips[2].Set("Timer", $(if ($st.Timer) { 'ON' } else { 'OFF' }), [int]$st.Timer)
        $chips[3].Set("Plan", $st.Plan, 2)
        $x = 22
        foreach ($ch in $chips) { $ch.Left = $x; $x += $ch.Width + 10 }
        $lblWpsNow.Text = $st.Win32
    } catch { Log "Status: $($_.Exception.Message)" 'warn' }
}
