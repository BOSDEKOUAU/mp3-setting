﻿# =====================================================================
#  SETTING MP3 V1 - Presets (.reg packs, SETTING MP3, FIX CPU, All, Restore)
# =====================================================================

# ---------- .REG PARSER (applies through Set-Reg so everything is backed up) ----------
function Apply-RegText([string]$Text, [string]$Title) {
    $key = $null; $n = 0
    foreach ($raw in ($Text -split "`r?`n")) {
        $line = $raw.Trim()
        if (-not $line -or $line.StartsWith(';') -or $line -like 'Windows Registry Editor*') { continue }
        if ($line -match '^\[(-?)(.+)\]$') {
            $key = $Matches[2].Trim()
            if ($Matches[1] -eq '-') { Log "  skip key delete: $key" 'warn'; $key = $null }
            continue
        }
        if (-not $key) { continue }
        if ($line -match '^"((?:[^"\\]|\\.)*)"\s*=\s*(.*)$') { $name = $Matches[1] -replace '\\\\', '\'; $data = $Matches[2].Trim() }
        elseif ($line -match '^@\s*=\s*(.*)$') { $name = ''; $data = $Matches[1].Trim() }
        else { continue }

        if ($data -eq '-')                              { Remove-Reg $key $name }
        elseif ($data -match '^dword:([0-9a-fA-F]{1,8})$') { Set-Reg $key $name ([Convert]::ToUInt32($Matches[1], 16)) 'DWord' }
        elseif ($data -match '^"(.*)"$')                 { Set-Reg $key $name ($Matches[1] -replace '\\"', '"' -replace '\\\\', '\') 'String' }
        else { Log "  skip (unsupported): $line" 'warn'; continue }
        $n++
    }
    Log "$Title : $n ค่า" 'ok'
}

$RegWindows = @'
Windows Registry Editor Version 5.00

; Accounts Tab ( Disable Syncing )
[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync]
"SyncPolicy"=dword:00000005

[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Personalization]
"Enabled"=dword:00000000

[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\BrowserSettings]
"Enabled"=dword:00000000

[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Credentials]
"Enabled"=dword:00000000

[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Accessibility]
"Enabled"=dword:00000000

[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Windows]
"Enabled"=dword:00000000

; Personalization Tab ( Disable Transparency )
[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize]
"EnableTransparency"=dword:00000000

; Disable Game Bar & Game DVR
[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\PolicyManager\default\ApplicationManagement\AllowGameDVR]
"value"=dword:00000000

[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\GameDVR]
"AllowGameDVR"=dword:00000000

[HKEY_CURRENT_USER\System\GameConfigStore]
"GameDVR_Enabled"=dword:00000000

[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR]
"AppCaptureEnabled"=dword:00000000

; Enable Game Mode
[HKEY_CURRENT_USER\SOFTWARE\Microsoft\GameBar]
"AllowAutoGameMode"=dword:00000001
"AutoGameModeEnabled"=dword:00000001

; Enable Hardware Accelerated GPU Scheduling
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\GraphicsDrivers]
"HwSchMode"=dword:00000002

; Disable Variable Refresh Rate
[HKEY_CURRENT_USER\SOFTWARE\Microsoft\DirectX\UserGpuPreferences]
"DirectXUserGlobalSettings"="VRROptimizeEnable=0;"

; Ease of Access ( Disable Ease Of Access Features )
[HKEY_CURRENT_USER\Control Panel\Accessibility\MouseKeys]
"Flags"="0"

[HKEY_CURRENT_USER\Control Panel\Accessibility\StickyKeys]
"Flags"="0"

[HKEY_CURRENT_USER\Control Panel\Accessibility\Keyboard Response]
"Flags"="0"

[HKEY_CURRENT_USER\Control Panel\Accessibility\ToggleKeys]
"Flags"="0"

; Privacy - General
[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo]
"Enabled"=dword:00000000

[HKEY_CURRENT_USER\Control Panel\International\User Profile]
"HttpAcceptLanguageOptOut"=dword:00000001

[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"Start_TrackProgs"=dword:00000000

[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager]
"SubscribedContent-338393Enabled"=dword:00000000
"SubscribedContent-353694Enabled"=dword:00000000
"SubscribedContent-353696Enabled"=dword:00000000

; Speech
[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy]
"HasAccepted"=dword:00000000

; Inking & Typing Personalization
[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Personalization\Settings]
"AcceptedPrivacyPolicy"=dword:00000000

[HKEY_CURRENT_USER\SOFTWARE\Microsoft\InputPersonalization]
"RestrictImplicitInkCollection"=dword:00000001
"RestrictImplicitTextCollection"=dword:00000001

[HKEY_CURRENT_USER\SOFTWARE\Microsoft\InputPersonalization\TrainedDataStore]
"HarvestContacts"=dword:00000000

; Diagnostics & Feedback
[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack]
"ShowedToastAtLevel"=dword:00000001

[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DataCollection]
"AllowTelemetry"=dword:00000000

[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Privacy]
"TailoredExperiencesWithDiagnosticDataEnabled"=dword:00000000

[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\EventTranscriptKey]
"EnableEventTranscript"=dword:00000000

[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Siuf\Rules]
"NumberOfSIUFInPeriod"=dword:00000000
"PeriodInNanoSeconds"=-

; Activity History
[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\System]
"PublishUserActivities"=dword:00000000
"UploadUserActivities"=dword:00000000

; App Permissions
[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userNotificationListener]
"Value"="Deny"

[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location]
"Value"="Deny"

[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appDiagnostics]
"Value"="Deny"

[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userAccountInformation]
"Value"="Deny"

; Disable Background Apps
[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications]
"GlobalUserDisabled"=dword:00000001

[HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Search]
"BackgroundAppGlobalToggle"=dword:00000000
'@

$RegLatency = @'
Windows Registry Editor Version 5.00

; Disable Network Throttling
[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile]
"NetworkThrottlingIndex"=dword:ffffffff
"SystemResponsiveness"=dword:00000000

; DirectX Frame Latency
[HKEY_CURRENT_USER\SOFTWARE\Microsoft\DirectX]
"MaxFrameLatency"=dword:00000001
"MaxQueuedFrames"=dword:00000001

; GPU Frame Queue
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\GraphicsDrivers]
"MaxFrameLatency"=dword:00000001

; UDP Network Performance
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\AFD\Parameters]
"FastSendDatagramThreshold"=dword:000005dc
"DefaultReceiveWindow"=dword:00040000
"DefaultSendWindow"=dword:00040000
"EnableDynamicBacklog"=dword:00000001
"MinimumDynamicBacklog"=dword:00000014
"MaximumDynamicBacklog"=dword:00004e20
'@

function Apply-RegWindows { Apply-RegText $RegWindows 'Windows Privacy & Gaming' }
function Apply-RegLatency { Apply-RegText $RegLatency 'Latency & UDP Network' }

function Export-RegFile([string]$Text, [string]$Name) {
    $dlg = New-Object System.Windows.Forms.SaveFileDialog
    $dlg.FileName = $Name; $dlg.Filter = 'Registry file (*.reg)|*.reg'
    if ($dlg.ShowDialog($script:Form) -ne 'OK') { throw "ยกเลิก" }
    # .reg must be UTF-16 LE
    [IO.File]::WriteAllText($dlg.FileName, ($Text -replace "`r?`n", "`r`n"), [Text.Encoding]::Unicode)
    Log "Saved: $($dlg.FileName)" 'ok'
}

# ---------- helpers ----------
function Set-SvcStart([string]$Name, [int]$Start) {   # 2 auto, 3 manual, 4 disabled
    Set-Reg "HKLM\SYSTEM\CurrentControlSet\Services\$Name" 'Start' $Start
}
function Bcd([string]$Args_, [switch]$Quiet) { Exec "bcdedit $Args_" -Quiet:$Quiet }

# ---------- SETTING MP3 ----------
function Invoke-SettingMp3 {
    # 1) GPU Scheduling / DirectX
    Set-Reg 'HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' 0
    Set-Reg 'HKLM\SOFTWARE\Microsoft\DirectX' 'MaxFrameLatency' 1
    Set-Reg 'HKCU\Software\Microsoft\Windows\DWM' 'MaxQueuedFrames' 1
    Log '  [1/10] GPU Scheduling / DirectX' 'ok'

    # 2) Multimedia Scheduler
    $mm = 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'
    Set-Reg $mm 'SystemResponsiveness' 0
    Set-Reg "$mm\Tasks\Games" 'GPU Priority' 8
    Set-Reg "$mm\Tasks\Games" 'Priority' 6
    Set-Reg "$mm\Tasks\Games" 'Scheduling Category' 'High' 'String'
    Log '  [2/10] Multimedia Scheduler' 'ok'

    # 3) Input Precision
    $m = 'HKCU\Control Panel\Mouse'
    Set-Reg $m 'MouseSpeed' '0' 'String'
    Set-Reg $m 'MouseThreshold1' '0' 'String'
    Set-Reg $m 'MouseThreshold2' '0' 'String'
    Set-Reg $m 'MouseSensitivity' '8' 'String'
    Set-Reg 'HKLM\SYSTEM\CurrentControlSet\Services\mouclass\Parameters' 'MouseDataQueueSize' 64
    Set-Reg 'HKLM\SYSTEM\CurrentControlSet\Services\kbdclass\Parameters' 'KeyboardDataQueueSize' 32
    Log '  [3/10] Input Precision' 'ok'

    # 4) Network (GPEdit + Timing Stable)
    Set-Reg 'HKLM\SOFTWARE\Policies\Microsoft\Windows\Psched' 'NonBestEffortLimit' 0
    Exec 'netsh int tcp set global autotuninglevel=restricted'
    Exec 'netsh int tcp set heuristics disabled'
    Exec 'netsh int tcp set global rss=disabled'
    Exec 'netsh int tcp set global chimney=disabled' -Quiet    # removed on new Windows builds
    Exec 'netsh int tcp set global ecncapability=disabled'
    Exec 'netsh int tcp set global timestamps=disabled'
    Exec 'netsh int tcp set global pacingprofile=off' -Quiet
    $tp = 'HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters'
    Set-Reg $tp 'TcpAckFrequency' 1
    Set-Reg $tp 'TCPNoDelay' 1
    Set-Reg $tp 'TcpDelAckTicks' 0
    Set-Reg $tp 'TcpTimedWaitDelay' 14
    Set-Reg $tp 'TcpMaxDataRetransmissions' 2
    Set-Reg $tp 'EnableRSS' 0
    Set-Reg $tp 'EnableTCPA' 0
    Set-Reg 'HKLM\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization' 'DODownloadMode' 0
    Set-SvcStart 'BITS' 4
    Set-Reg 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance' 'MaintenanceDisabled' 1
    $script:State['NetshTweaked'] = $true; Save-State
    Log '  [4/10] Network' 'ok'

    # 5) CPU / Power Lock
    Save-PowerScheme
    Exec 'powercfg /setactive SCHEME_MIN'
    Bcd '/set disabledynamictick yes'
    Bcd '/set useplatformclock no'
    Bcd '/set tscsyncpolicy Enhanced'
    Set-Reg 'HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' 'PowerThrottlingOff' 1
    Set-Reg 'HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Power' 'HiberbootEnabled' 0
    Set-Reg 'HKLM\SYSTEM\CurrentControlSet\Control\Power' 'PlatformAoAcOverride' 0
    Exec 'powercfg -setacvalueindex SCHEME_CURRENT SUB_PROCESSOR IDLEDISABLE 1'
    Exec 'powercfg -setactive SCHEME_CURRENT'
    Log '  [5/10] CPU / Power Lock' 'ok'

    # 6) Timer & Scheduler
    Set-Reg 'HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel' 'GlobalTimerResolutionRequests' 1
    Set-Reg $PriorityKey 'Win32PrioritySeparation' 26
    Set-Reg 'HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Scheduler' 'EnableIdleNodeBalancer' 0
    Log '  [6/10] Timer & Scheduler' 'ok'

    # 7) Defender & Telemetry
    Set-Reg 'HKLM\SOFTWARE\Policies\Microsoft\Windows Defender' 'DisableAntiSpyware' 1
    Set-Reg 'HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection' 'AllowTelemetry' 0
    Set-SvcStart 'DiagTrack' 4
    Log '  [7/10] Defender & Telemetry' 'ok'

    # 8) GameDVR & Xbox
    Set-Reg 'HKCU\System\GameConfigStore' 'GameDVR_Enabled' 0
    Set-Reg 'HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR' 'AppCaptureEnabled' 0
    Set-Reg 'HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR' 'AllowGameDVR' 0
    Set-Reg 'HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR' 'AllowBroadcasting' 0
    Log '  [8/10] GameDVR & Xbox' 'ok'

    # 9) Visual / Animation
    Set-Reg 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' 'VisualFXSetting' 2
    Set-Reg 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'ListviewAlphaSelect' 0
    Log '  [9/10] Visual / Animation' 'ok'

    # 10) Background Apps
    Set-Reg 'HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications' 'GlobalUserDisabled' 1
    Set-Reg 'HKCU\Software\Microsoft\Windows\CurrentVersion\Search' 'BackgroundAppGlobalToggle' 0
    Log '  [10/10] Background Apps' 'ok'
    Log 'SETTING MP3 ติดตั้งสำเร็จ - กรุณารีสตาร์ทเครื่อง 1 ครั้ง' 'ok'
}

# ---------- FIX CPU 100% ----------
function Invoke-FixCpu {
    Exec 'powercfg -setacvalueindex SCHEME_CURRENT SUB_PROCESSOR IDLEDISABLE 0'
    Exec 'powercfg -setdcvalueindex SCHEME_CURRENT SUB_PROCESSOR IDLEDISABLE 0'
    Exec 'powercfg -setactive SCHEME_CURRENT'
    Log '  คืนค่า CPU Idle' 'ok'
    $mmk = 'HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management'
    Set-Reg "$mmk\PrefetchParameters" 'EnablePrefetcher' 3
    Set-Reg "$mmk\PrefetchParameters" 'EnableSuperfetch' 3
    Log '  คืนค่า Prefetch / Superfetch' 'ok'
    Remove-Reg $mmk 'DisablePagingExecutive'
    Remove-Reg $mmk 'IoPageLockLimit'
    Log '  ลบค่า Memory ที่ทำให้การรายงานเพี้ยน' 'ok'
    Bcd '/deletevalue useplatformtick' -Quiet
    Bcd '/deletevalue useplatformclock' -Quiet
    Bcd '/deletevalue disabledynamictick' -Quiet
    Bcd '/deletevalue tscsyncpolicy' -Quiet
    Log '  คืนค่า BCD timing เป็น default' 'ok'
    Log 'FIX CPU เสร็จสิ้น - กรุณารีสตาร์ทเครื่อง 1 ครั้ง' 'ok'
}

# ---------- QUICK APPLY ALL ----------
$QuickCfg = @{ Priority = 0x26; App = 'FiveM_GTAProcess.exe'; AppPriority = 'High'; KbdQueue = '20'; MouQueue = '20' }
function Apply-AllPersistent {
    Log '[1/7] CPU';     Set-Priority $QuickCfg.Priority; Set-AppPriorityPerm $QuickCfg.App $QuickCfg.AppPriority
    Log '[2/7] Input';   Set-KbdQueue $QuickCfg.KbdQueue; Set-MouQueue $QuickCfg.MouQueue
    Log '[3/7] QoS';     Apply-QoS
    Log '[4/7] Power';   Install-Mp3PowerPlan
    Log '[5/7] Timer';   Install-TimerRes
    Log '[6/7] Latency'; Apply-RegLatency
    Log '[7/7] Network'; Apply-NetworkTweaks
}

# ---------- RESTORE ALL ----------
function Restore-All {
    Remove-QoS
    Remove-TimerRes
    Exec 'netsh int tcp set global autotuninglevel=normal' -Quiet
    Exec 'netsh int tcp set global rss=enabled' -Quiet
    Exec 'netsh int tcp set global rsc=enabled' -Quiet
    Exec 'netsh int tcp set global ecncapability=default' -Quiet
    Exec 'netsh int tcp set global timestamps=default' -Quiet
    Exec 'netsh int tcp set global initialRto=3000' -Quiet
    Exec 'netsh int tcp set heuristics default' -Quiet
    Exec 'netsh int tcp set supplemental template=internet congestionprovider=cubic' -Quiet
    Log 'netsh -> default' 'ok'
    foreach ($v in 'disabledynamictick', 'useplatformclock', 'useplatformtick', 'tscsyncpolicy') { Bcd "/deletevalue $v" -Quiet }
    Log 'bcdedit -> default' 'ok'
    Exec 'powercfg -setacvalueindex SCHEME_CURRENT SUB_PROCESSOR IDLEDISABLE 0' -Quiet
    Exec 'powercfg -setactive SCHEME_CURRENT' -Quiet
    $orig = $script:State['PowerScheme']
    Exec ("powercfg -setactive " + $(if ($orig) { $orig } else { $BalancedGuid })) -Quiet
    foreach ($g in @($script:State['ImportedPlans'])) { if ($g) { Exec "powercfg -delete $g" -Quiet } }
    Log 'Power plan -> เดิม' 'ok'
    Restore-Registry
    $hadNet = $script:State['NetTweaked']
    $script:State = [ordered]@{}; Save-State
    if ($hadNet) { Restart-Nics @(Get-NicKeys) }
    Log 'คืนค่าทั้งหมดแล้ว - กรุณารีสตาร์ทเครื่อง' 'ok'
}

# ---------- STATUS ----------
function Get-Mp3Status {
    $w = Get-Reg $PriorityKey 'Win32PrioritySeparation'
    [pscustomobject]@{
        Win32 = if ($null -ne $w) { '0x{0:X2}' -f $w } else { 'N/A' }
        QoS   = Test-QoS
        Timer = Test-TimerRes
        Plan  = (Get-ActiveScheme).Name
    }
}
