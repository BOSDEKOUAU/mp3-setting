// SETTING MP3 V1 - modern WinForms controls (C# 5 / .NET Framework, compiled by Add-Type)
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Mp3UI
{
    public interface IAnimated { bool Tick(float dt); }

    /// One shared frame loop for every animation. Runs while the UI thread is idle and
    /// waits on DwmFlush() between frames, so motion is locked to the monitor refresh
    /// (60 Hz = 60 fps, 144 Hz = 144 fps). All animations are time-based (dt seconds).
    public static class Animator
    {
        [StructLayout(LayoutKind.Sequential)]
        struct MSG { public IntPtr hwnd; public uint message; public IntPtr wParam, lParam; public uint time; public int x, y; }
        [DllImport("user32.dll")] static extern bool PeekMessage(out MSG m, IntPtr h, uint min, uint max, uint remove);
        [DllImport("user32.dll")] static extern bool RedrawWindow(IntPtr h, IntPtr rc, IntPtr rgn, uint flags);
        [DllImport("dwmapi.dll")] static extern int DwmFlush();

        /// Frame cap. Frames stay vsync-aligned (e.g. 360 Hz screen @144 cap -> 120 fps, 60 Hz -> 60 fps).
        public static double MaxFps = 144;
        static List<IAnimated> active = new List<IAnimated>();
        static System.Diagnostics.Stopwatch clock = System.Diagnostics.Stopwatch.StartNew();
        static double last = -1, lastFrame;
        static bool hooked, inLoop;
        static Timer fallback;

        public static void Start(IAnimated a)
        {
            if (!active.Contains(a)) active.Add(a);
            if (last < 0) last = clock.Elapsed.TotalSeconds - 1.0 / 60;
            if (!hooked)
            {
                hooked = true;
                Application.Idle += OnIdle;
                // keeps animations alive while the thread is busy in DoEvents() (long actions)
                fallback = new Timer(); fallback.Interval = 50;
                fallback.Tick += delegate { if (active.Count > 0 && !inLoop && clock.Elapsed.TotalSeconds - lastFrame > 0.045) Pump(); };
                fallback.Start();
            }
        }

        public static void Pump()
        {
            double now = clock.Elapsed.TotalSeconds;
            float dt = (float)Math.Min(0.05, Math.Max(0.001, now - last));
            last = now; lastFrame = now;
            IAnimated[] snap = active.ToArray();
            foreach (IAnimated a in snap)
            {
                bool busy;
                try { busy = a.Tick(dt); } catch { busy = false; }
                if (!busy) active.Remove(a);
            }
            foreach (Form f in Application.OpenForms)
                if (f.IsHandleCreated && f.Visible) RedrawWindow(f.Handle, IntPtr.Zero, IntPtr.Zero, 0x0100 | 0x0080); // UPDATENOW | ALLCHILDREN
            if (active.Count == 0) last = -1;
        }

        static void OnIdle(object s, EventArgs e)
        {
            if (inLoop) return;
            inLoop = true;
            try
            {
                MSG m;
                while (active.Count > 0)
                {
                    if (clock.Elapsed.TotalSeconds - lastFrame >= 1.0 / MaxFps - 0.0005) Pump();
                    if (active.Count == 0 || PeekMessage(out m, IntPtr.Zero, 0, 0, 0)) break;
                    double t0 = clock.Elapsed.TotalSeconds;
                    if (DwmFlush() != 0 || clock.Elapsed.TotalSeconds - t0 < 0.0004)
                        System.Threading.Thread.Sleep(4);   // no DWM / returned instantly: don't spin
                }
            }
            finally { inLoop = false; }
        }
    }

    public static class Theme
    {
        public static Color Bg         = Color.FromArgb(241, 245, 252);
        public static Color Surface    = Color.White;
        public static Color Surface2   = Color.FromArgb(246, 248, 253);
        public static Color Border     = Color.FromArgb(225, 231, 243);
        public static Color Text       = Color.FromArgb(15, 23, 42);
        public static Color Muted      = Color.FromArgb(100, 116, 139);
        public static Color Accent     = Color.FromArgb(37, 99, 235);
        public static Color Accent2    = Color.FromArgb(14, 165, 233);
        public static Color AccentDeep = Color.FromArgb(30, 64, 175);
        public static Color AccentSoft = Color.FromArgb(224, 236, 255);
        public static Color Danger     = Color.FromArgb(225, 29, 72);
        public static Color Warn       = Color.FromArgb(245, 158, 11);
        public static Color Success    = Color.FromArgb(16, 185, 129);
        public const string FontName = "Segoe UI";
        public const string IconFont = "Segoe MDL2 Assets";
        public static Font F(float size, FontStyle st) { return new Font(FontName, size, st, GraphicsUnit.Point); }
    }

    public static class Gfx
    {
        public static GraphicsPath Round(RectangleF r, float rad)
        {
            GraphicsPath p = new GraphicsPath();
            float d = Math.Min(rad * 2, Math.Min(r.Width, r.Height));
            if (d <= 0.5f) { p.AddRectangle(r); return p; }
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }
        public static Color Lerp(Color a, Color b, float t)
        {
            t = Math.Max(0f, Math.Min(1f, t));
            return Color.FromArgb((int)(a.A + (b.A - a.A) * t), (int)(a.R + (b.R - a.R) * t),
                                  (int)(a.G + (b.G - a.G) * t), (int)(a.B + (b.B - a.B) * t));
        }
        public static Color A(Color c, int alpha) { return Color.FromArgb(Math.Max(0, Math.Min(255, alpha)), c); }
        public static float Ease(float t) { t = Math.Max(0f, Math.Min(1f, t)); return 1f - (float)Math.Pow(1f - t, 3); }
        public static float EaseOutQuint(float t) { t = Math.Max(0f, Math.Min(1f, t)); return 1f - (float)Math.Pow(1f - t, 5); }
        public static float EaseInCubic(float t) { t = Math.Max(0f, Math.Min(1f, t)); return t * t * t; }
        public static void Hq(Graphics g)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.CompositingQuality = CompositingQuality.HighQuality;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        }
        public static void SoftShadow(Graphics g, RectangleF r, float rad, Color c, int layers, int alpha)
        {
            for (int i = 1; i <= layers; i++)
            {
                RectangleF s = r; s.Offset(0, i); s.Inflate(-1, 0);
                using (GraphicsPath p = Round(s, rad))
                using (SolidBrush b = new SolidBrush(A(c, Math.Max(1, alpha - i * (alpha / (layers + 1))))))
                    g.FillPath(b, p);
            }
        }
        /// GDI+ text (honors path clips, unlike TextRenderer). Vertically centered, no wrap.
        public static void Label(Graphics g, string s, Font f, RectangleF r, Color c, bool center)
        {
            TextRenderingHint old = g.TextRenderingHint;
            g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            using (StringFormat sf = new StringFormat(StringFormatFlags.NoWrap))
            using (SolidBrush b = new SolidBrush(c))
            {
                sf.Alignment = center ? StringAlignment.Center : StringAlignment.Near;
                sf.LineAlignment = StringAlignment.Center;
                sf.Trimming = StringTrimming.None;
                g.DrawString(s, f, b, r, sf);
            }
            g.TextRenderingHint = old;
        }
        public static void Gradient(Graphics g, GraphicsPath p, RectangleF r, Color a, Color b, float angle)
        {
            RectangleF gr = new RectangleF(r.X - 1, r.Y - 1, r.Width + 2, r.Height + 2);
            using (LinearGradientBrush lb = new LinearGradientBrush(gr, a, b, angle)) g.FillPath(lb, p);
        }
    }

    /// Damped spring (semi-implicit Euler, 4 ms sub-steps => identical feel at any frame rate).
    /// stiffness ~ speed, damping ratio < 1 gives a soft overshoot, 1 = no overshoot.
    public class Spring
    {
        public float X, V;
        public float Stiffness = 260f, DampingRatio = 0.82f;
        public Spring() { }
        public Spring(float k, float zeta) { Stiffness = k; DampingRatio = zeta; }
        public void Snap(float x) { X = x; V = 0; }
        /// returns true while still moving
        public bool Step(float target, float dt)
        {
            float c = 2f * (float)Math.Sqrt(Stiffness) * DampingRatio;
            int n = Math.Max(1, (int)Math.Ceiling(dt / 0.004f));
            float h = dt / n;
            for (int i = 0; i < n; i++)
            {
                float a = Stiffness * (target - X) - c * V;
                V += a * h;
                X += V * h;
            }
            if (Math.Abs(target - X) < 0.05f && Math.Abs(V) < 0.6f) { X = target; V = 0; return false; }
            return true;
        }
    }

    /// Base control: double buffered, transparent corners, driven by the shared Animator.
    public class AnimControl : Control, IAnimated
    {
        public AnimControl()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint |
                     ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
        }
        /// dt = seconds since last frame; return true while still animating.
        protected virtual bool Step(float dt) { return false; }
        public bool Tick(float dt)
        {
            if (IsDisposed) return false;
            bool busy = Step(dt);
            Invalidate();
            return busy;
        }
        protected void Kick() { Animator.Start(this); }
        /// Frame-rate independent exponential approach (rate = 1/seconds).
        protected static float Approach(float v, float target, float rate, float dt)
        {
            float d = target - v;
            if (Math.Abs(d) < 0.003f) return target;
            return v + d * (1f - (float)Math.Exp(-rate * dt));
        }
    }

    public class ModernButton : AnimControl
    {
        public bool Accent;
        public bool Danger;
        public string Glyph;
        public int Radius = 12;
        float hover, press, sweep = -1f, ripple = -1f;
        Point rp;
        bool isHover, isDown;
        Font font, iconFont;

        public ModernButton()
        {
            Cursor = Cursors.Hand;
            font = Theme.F(9.25f, FontStyle.Bold);
            iconFont = new Font(Theme.IconFont, 10.5f);
            Size = new Size(160, 44);
        }
        protected override void OnMouseEnter(EventArgs e) { isHover = true; sweep = 0f; Kick(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { isHover = false; isDown = false; Kick(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) { isDown = true; ripple = 0f; rp = e.Location; Kick(); }
            base.OnMouseDown(e);
        }
        protected override void OnMouseUp(MouseEventArgs e) { isDown = false; Kick(); base.OnMouseUp(e); }
        protected override void OnTextChanged(EventArgs e) { Invalidate(); base.OnTextChanged(e); }
        protected override void OnEnabledChanged(EventArgs e) { Invalidate(); base.OnEnabledChanged(e); }

        protected override bool Step(float dt)
        {
            float ht = isHover ? 1f : 0f, pt = isDown ? 1f : 0f;
            hover = Approach(hover, ht, 13f, dt);
            press = Approach(press, pt, 28f, dt);
            bool busy = hover != ht || press != pt;
            if (sweep >= 0) { sweep += 1.35f * dt; if (sweep > 1.3f) sweep = -1f; else busy = true; }
            if (ripple >= 0) { ripple += 2.2f * dt; if (ripple > 1f) ripple = -1f; else busy = true; }
            return busy;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics; Gfx.Hq(g);
            bool filled = Accent || Danger;
            float lift = hover * 1.5f - press * 1.5f;
            float ins = press * 1.2f;
            RectangleF r = new RectangleF(1 + ins, 2.5f - lift + ins, Width - 2.5f - ins * 2, Height - 8f - ins * 2);

            Color c1 = Danger ? Theme.Danger : Theme.Accent;
            Color c2 = Danger ? Color.FromArgb(244, 63, 94) : Theme.Accent2;
            if (!Enabled) { c1 = Color.FromArgb(203, 213, 225); c2 = c1; }

            if (filled) Gfx.SoftShadow(g, r, Radius, c1, 5, (int)(34 + hover * 30));
            else Gfx.SoftShadow(g, r, Radius, Theme.AccentDeep, 3, (int)(10 + hover * 14));

            using (GraphicsPath p = Gfx.Round(r, Radius))
            {
                if (filled)
                {
                    Gfx.Gradient(g, p, r, Gfx.Lerp(c1, Color.White, hover * 0.08f), Gfx.Lerp(c2, Color.White, hover * 0.12f), 25f);
                    // glassy top highlight
                    RectangleF hl = new RectangleF(r.X + 1, r.Y + 1, r.Width - 2, r.Height * 0.5f);
                    using (GraphicsPath hp = Gfx.Round(hl, Radius - 1))
                    using (LinearGradientBrush hb = new LinearGradientBrush(new RectangleF(hl.X, hl.Y - 1, hl.Width, hl.Height + 2),
                           Color.FromArgb(46, 255, 255, 255), Color.FromArgb(0, 255, 255, 255), 90f))
                        g.FillPath(hb, hp);
                }
                else
                {
                    using (SolidBrush fb = new SolidBrush(Gfx.Lerp(Theme.Surface, Theme.AccentSoft, hover * 0.75f))) g.FillPath(fb, p);
                    using (Pen bp = new Pen(Gfx.Lerp(Theme.Border, Color.FromArgb(147, 180, 245), hover), 1f)) g.DrawPath(bp, p);
                }

                Region old = g.Clip;
                g.SetClip(p, CombineMode.Intersect);
                if (filled && sweep >= 0)
                {
                    float cx = r.X - 90 + sweep * (r.Width + 180);
                    PointF[] band = { new PointF(cx - 30, r.Bottom), new PointF(cx + 20, r.Top), new PointF(cx + 70, r.Top), new PointF(cx + 20, r.Bottom) };
                    using (LinearGradientBrush sb = new LinearGradientBrush(new PointF(cx - 31, 0), new PointF(cx + 71, 0), Color.Transparent, Color.Transparent))
                    {
                        ColorBlend cb = new ColorBlend(3);
                        cb.Colors = new Color[] { Color.FromArgb(0, 255, 255, 255), Color.FromArgb(80, 255, 255, 255), Color.FromArgb(0, 255, 255, 255) };
                        cb.Positions = new float[] { 0f, 0.5f, 1f };
                        sb.InterpolationColors = cb;
                        g.FillPolygon(sb, band);
                    }
                }
                if (ripple >= 0)
                {
                    float rad = Gfx.Ease(ripple) * Math.Max(Width, Height) * 1.25f;
                    int al = (int)((1f - ripple) * (filled ? 80 : 55));
                    using (SolidBrush rb = new SolidBrush(Gfx.A(filled ? Color.White : Theme.Accent, al)))
                        g.FillEllipse(rb, rp.X - rad, rp.Y - rad, rad * 2, rad * 2);
                }
                g.Clip = old;
            }

            Color tc = filled ? Color.White : Gfx.Lerp(Theme.Text, Theme.Accent, hover);
            if (!Enabled) tc = filled ? Color.White : Theme.Muted;
            Rectangle tr = Rectangle.Round(r);
            string txt = Text ?? "";
            TextFormatFlags fl = TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine;
            Size ts = TextRenderer.MeasureText(g, txt, font, new Size(9999, 99), fl);
            int gw = string.IsNullOrEmpty(Glyph) ? 0 : 24;
            int x0 = tr.X + (tr.Width - ts.Width - gw) / 2;
            if (gw > 0)
            {
                // grayscale AA for icons (ClearType adds colored fringes to thin glyph strokes)
                g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
                using (StringFormat sf = new StringFormat())
                using (SolidBrush gb = new SolidBrush(tc))
                {
                    sf.Alignment = StringAlignment.Center; sf.LineAlignment = StringAlignment.Center;
                    g.DrawString(Glyph, iconFont, gb, new RectangleF(x0 - 2, tr.Y + 1, 22, tr.Height), sf);
                }
                g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
            }
            TextRenderer.DrawText(g, txt, font, new Rectangle(x0 + gw, tr.Y, ts.Width + 6, tr.Height), tc, fl);
        }
    }

    public class Card : Panel
    {
        public string Title = "";
        public int Radius = 18;
        Font tf;
        public Card()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint |
                     ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
            tf = Theme.F(9.5f, FontStyle.Bold);
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics; Gfx.Hq(g);
            RectangleF r = new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 6f);
            Gfx.SoftShadow(g, r, Radius, Theme.AccentDeep, 5, 16);
            using (GraphicsPath p = Gfx.Round(r, Radius))
            {
                using (SolidBrush b = new SolidBrush(Theme.Surface)) g.FillPath(b, p);
                using (Pen pen = new Pen(Theme.Border)) g.DrawPath(pen, p);
            }
            if (!string.IsNullOrEmpty(Title))
            {
                RectangleF bar = new RectangleF(20, 19, 4, 16);
                using (GraphicsPath bp = Gfx.Round(bar, 2)) Gfx.Gradient(g, bp, bar, Theme.Accent, Theme.Accent2, 90f);
                TextRenderer.DrawText(g, Title, tf, new Point(32, 17), Theme.Text, TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding);
            }
        }
    }

    /// Animated gradient banner for the dashboard.
    public class Hero : AnimControl
    {
        public string Title = "MP3 STEPLNW";
        public string Sub = "FIVEM PERFORMANCE TWEAKER  •  BLUE EDITION";
        public string Badge = "V1  •  READY";
        float ph;
        Font tf, sf, bf;
        Form host;
        public Hero()
        {
            tf = Theme.F(28f, FontStyle.Bold);
            sf = Theme.F(9f, FontStyle.Bold);
            bf = Theme.F(8.5f, FontStyle.Bold);
        }
        protected override void OnVisibleChanged(EventArgs e) { base.OnVisibleChanged(e); if (Visible) Kick(); }
        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            host = FindForm();
            if (host != null) host.Resize += delegate { if (host.WindowState != FormWindowState.Minimized) Kick(); };
            Kick();
        }
        protected override bool Step(float dt)
        {
            if (host != null && host.WindowState == FormWindowState.Minimized) return false;
            ph += 0.5f * dt;
            return Visible;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics; Gfx.Hq(g);
            RectangleF r = new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 7f);
            Gfx.SoftShadow(g, r, 22, Theme.Accent, 6, 40);
            using (GraphicsPath p = Gfx.Round(r, 22))
            {
                using (LinearGradientBrush lb = new LinearGradientBrush(new RectangleF(r.X - 1, r.Y - 1, r.Width + 2, r.Height + 2), Theme.AccentDeep, Theme.Accent2, 15f))
                {
                    ColorBlend cb = new ColorBlend(3);
                    cb.Colors = new Color[] { Theme.AccentDeep, Theme.Accent, Theme.Accent2 };
                    cb.Positions = new float[] { 0f, 0.55f, 1f };
                    lb.InterpolationColors = cb;
                    g.FillPath(lb, p);
                }
                Region old = g.Clip;
                g.SetClip(p, CombineMode.Intersect);
                for (int i = 0; i < 3; i++)
                {
                    float rad = 70 + i * 34;
                    float cx = r.Width * (0.58f + i * 0.16f) + (float)Math.Sin(ph * (1 + i * 0.35f) + i * 2) * 28;
                    float cy = r.Height * (0.2f + (i % 2) * 0.6f) + (float)Math.Cos(ph * (0.8f + i * 0.25f) + i) * 18;
                    using (SolidBrush b = new SolidBrush(Color.FromArgb(26 - i * 4, 255, 255, 255))) g.FillEllipse(b, cx - rad, cy - rad, rad * 2, rad * 2);
                }
                using (SolidBrush dot = new SolidBrush(Color.FromArgb(38, 255, 255, 255)))
                    for (float x = r.Width - 250; x < r.Width - 20; x += 16)
                        for (float y = 18; y < r.Height - 14; y += 16)
                            g.FillEllipse(dot, x, y, 2.2f, 2.2f);
                g.Clip = old;
            }
            g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            using (SolidBrush w = new SolidBrush(Color.White)) g.DrawString(Title, tf, w, 28, r.Y + 30);
            using (SolidBrush w2 = new SolidBrush(Color.FromArgb(215, 255, 255, 255))) g.DrawString(Sub, sf, w2, 34, r.Y + 86);

            SizeF bs = g.MeasureString(Badge, bf);
            RectangleF br = new RectangleF(r.Right - bs.Width - 56, r.Y + 22, bs.Width + 36, 28);
            using (GraphicsPath bp = Gfx.Round(br, 14))
            {
                using (SolidBrush gb = new SolidBrush(Color.FromArgb(46, 255, 255, 255))) g.FillPath(gb, bp);
                using (Pen gp = new Pen(Color.FromArgb(90, 255, 255, 255))) g.DrawPath(gp, bp);
            }
            float pulse = 0.5f + 0.5f * (float)Math.Sin(ph * 6);
            using (SolidBrush halo = new SolidBrush(Color.FromArgb((int)(60 * pulse), 52, 211, 153))) g.FillEllipse(halo, br.X + 9, br.Y + 7, 14, 14);
            using (SolidBrush dot = new SolidBrush(Color.FromArgb(52, 211, 153))) g.FillEllipse(dot, br.X + 12, br.Y + 10, 8, 8);
            using (SolidBrush w = new SolidBrush(Color.White)) g.DrawString(Badge, bf, w, br.X + 26, br.Y + (br.Height - bs.Height) / 2 + 1);
        }
    }

    /// Pill-style segmented selector (replaces ComboBox). The highlight moves like liquid:
    /// the leading edge springs ahead, the trailing edge catches up, so it stretches then settles.
    public class SegmentedPicker : AnimControl
    {
        string[] items = new string[0];
        int sel, hoverIdx = -1;
        bool placed;
        Spring left = new Spring(), right = new Spring();
        float hovA;
        Font f, fb;
        public event EventHandler SelectedIndexChanged;

        public SegmentedPicker()
        {
            Cursor = Cursors.Hand;
            f = Theme.F(9f, FontStyle.Regular);
            fb = Theme.F(9f, FontStyle.Bold);
            Size = new Size(300, 40);
        }
        public string[] Items
        {
            get { return items; }
            set { items = value ?? new string[0]; sel = Math.Max(0, Math.Min(sel, items.Length - 1)); placed = false; Invalidate(); }
        }
        public int SelectedIndex
        {
            get { return sel; }
            set
            {
                if (value < 0 || value >= items.Length) return;
                bool forward = value > sel;
                sel = value;
                // leading edge: fast & tight; trailing edge: softer with a little overshoot
                Spring lead = forward ? right : left, trail = forward ? left : right;
                lead.Stiffness = 560f; lead.DampingRatio = 0.9f;
                trail.Stiffness = 200f; trail.DampingRatio = 0.74f;
                Kick();
                if (SelectedIndexChanged != null) SelectedIndexChanged(this, EventArgs.Empty);
            }
        }
        public string SelectedItem { get { return items.Length == 0 ? null : items[sel]; } }
        float SegW { get { return items.Length == 0 ? Width : (Width - 8f) / items.Length; } }
        int Hit(int x) { return Math.Max(0, Math.Min(items.Length - 1, (int)((x - 4) / SegW))); }
        void Place() { if (!placed && items.Length > 0) { left.Snap(4 + sel * SegW); right.Snap(4 + (sel + 1) * SegW); placed = true; } }

        protected override void OnResize(EventArgs e) { placed = false; base.OnResize(e); }
        protected override void OnMouseMove(MouseEventArgs e) { int h = Hit(e.X); if (h != hoverIdx) { hoverIdx = h; hovA = 0; Kick(); } base.OnMouseMove(e); }
        protected override void OnMouseLeave(EventArgs e) { hoverIdx = -1; Kick(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e) { if (items.Length > 0 && e.Button == MouseButtons.Left) SelectedIndex = Hit(e.X); base.OnMouseDown(e); }
        protected override bool Step(float dt)
        {
            Place();
            float sw = SegW;
            bool a = left.Step(4 + sel * sw, dt);
            bool b = right.Step(4 + (sel + 1) * sw, dt);
            float ht = hoverIdx >= 0 ? 1f : 0f;
            hovA = Approach(hovA, ht, 14f, dt);
            return a || b || hovA != ht;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Place();
            Graphics g = e.Graphics; Gfx.Hq(g);
            RectangleF r = new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 2.5f);
            using (GraphicsPath p = Gfx.Round(r, 12))
            {
                using (SolidBrush b = new SolidBrush(Theme.Surface2)) g.FillPath(b, p);
                using (Pen pen = new Pen(Theme.Border)) g.DrawPath(pen, p);
            }
            if (items.Length == 0) return;
            float sw = SegW;
            if (hoverIdx >= 0 && hoverIdx != sel && hovA > 0.01f)
            {
                RectangleF hr = new RectangleF(4 + hoverIdx * sw, 4, sw, r.Height - 7);
                hr.Inflate(-3f * (1f - hovA), -2f * (1f - hovA));
                using (GraphicsPath hp = Gfx.Round(hr, 9))
                using (SolidBrush hb = new SolidBrush(Gfx.A(Theme.AccentSoft, (int)(255 * hovA)))) g.FillPath(hb, hp);
            }
            float l = Math.Min(left.X, right.X - 12), rr = Math.Max(right.X, l + 12);
            RectangleF ir = new RectangleF(l, 4, rr - l, r.Height - 7);
            Gfx.SoftShadow(g, ir, 9, Theme.Accent, 3, 40);
            using (GraphicsPath ip = Gfx.Round(ir, 9))
            {
                // pass 1: labels in normal color (outside the pill)
                for (int i = 0; i < items.Length; i++)
                {
                    Color baseC = i == hoverIdx ? Gfx.Lerp(Theme.Muted, Theme.Accent, hovA) : Theme.Muted;
                    Gfx.Label(g, items[i], i == sel ? fb : f, new RectangleF(4 + i * sw, 4, sw, r.Height - 7), baseC, true);
                }
                // pass 2: pill + white labels clipped to the pill -> color splits exactly at the edge
                Gfx.Gradient(g, ip, ir, Theme.Accent, Theme.Accent2, 25f);
                Region old = g.Clip;
                g.SetClip(ip, CombineMode.Intersect);
                for (int i = 0; i < items.Length; i++)
                    Gfx.Label(g, items[i], i == sel ? fb : f, new RectangleF(4 + i * sw, 4, sw, r.Height - 7), Color.White, true);
                g.Clip = old;
            }
        }
    }

    /// Rounded text input with animated focus ring.
    public class ModernTextBox : AnimControl
    {
        public TextBox Box = new TextBox();
        float focus;
        public ModernTextBox()
        {
            Box.BorderStyle = BorderStyle.None;
            Box.BackColor = Theme.Surface2;
            Box.ForeColor = Theme.Text;
            Box.Font = Theme.F(10f, FontStyle.Regular);
            Controls.Add(Box);
            Box.GotFocus += delegate { Kick(); };
            Box.LostFocus += delegate { Kick(); };
            Cursor = Cursors.IBeam;
            Size = new Size(240, 40);
        }
        public override string Text { get { return Box.Text; } set { Box.Text = value; } }
        protected override void OnLayout(LayoutEventArgs e)
        {
            base.OnLayout(e);
            Box.Location = new Point(14, (Height - Box.Height) / 2 - 1);
            Box.Width = Width - 28;
        }
        protected override void OnMouseDown(MouseEventArgs e) { Box.Focus(); base.OnMouseDown(e); }
        protected override bool Step(float dt) { float t = Box.Focused ? 1f : 0f; focus = Approach(focus, t, 14f, dt); return focus != t; }
        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics; Gfx.Hq(g);
            RectangleF outer = new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 1.5f);
            if (focus > 0)
                using (GraphicsPath op = Gfx.Round(outer, 13))
                using (SolidBrush ob = new SolidBrush(Gfx.A(Theme.AccentSoft, (int)(255 * focus)))) g.FillPath(ob, op);
            RectangleF r = new RectangleF(2.5f, 2.5f, Width - 5.5f, Height - 5.5f);
            using (GraphicsPath p = Gfx.Round(r, 11))
            {
                using (SolidBrush b = new SolidBrush(Theme.Surface2)) g.FillPath(b, p);
                using (Pen pen = new Pen(Gfx.Lerp(Theme.Border, Theme.Accent, focus), 1f + focus * 0.5f)) g.DrawPath(pen, p);
            }
        }
    }

    /// Small status pill: colored dot + label + value. state: 0 off, 1 on, 2 info.
    public class StatusChip : Control
    {
        string label = "", value = "";
        int state;
        Font lf, vf;
        public StatusChip()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint |
                     ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
            lf = Theme.F(8.75f, FontStyle.Regular);
            vf = Theme.F(8.75f, FontStyle.Bold);
            Height = 36;
        }
        public void Set(string l, string v, int st)
        {
            label = l ?? ""; value = v ?? ""; state = st;
            TextFormatFlags fl = TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix;
            Width = 34 + TextRenderer.MeasureText(label, lf, Size.Empty, fl).Width + 6 + TextRenderer.MeasureText(value, vf, Size.Empty, fl).Width + 16;
            Invalidate();
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics; Gfx.Hq(g);
            RectangleF r = new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 1.5f);
            using (GraphicsPath p = Gfx.Round(r, r.Height / 2))
            {
                using (SolidBrush b = new SolidBrush(Theme.Surface2)) g.FillPath(b, p);
                using (Pen pen = new Pen(Theme.Border)) g.DrawPath(pen, p);
            }
            Color dc = state == 1 ? Theme.Success : (state == 2 ? Theme.Accent : Color.FromArgb(148, 163, 184));
            float cy = Height / 2f;
            using (SolidBrush hb = new SolidBrush(Gfx.A(dc, 55))) g.FillEllipse(hb, 10, cy - 7, 14, 14);
            using (SolidBrush db = new SolidBrush(dc)) g.FillEllipse(db, 13, cy - 4, 8, 8);
            TextFormatFlags fl = TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine;
            int lw = TextRenderer.MeasureText(g, label, lf, Size.Empty, fl).Width;
            TextRenderer.DrawText(g, label, lf, new Rectangle(32, 0, lw + 4, Height), Theme.Muted, fl);
            TextRenderer.DrawText(g, value, vf, new Rectangle(32 + lw + 6, 0, Width, Height), Theme.Text, fl);
        }
    }

    /// Slide-in notification. kind: 0 info, 1 ok, 2 warn, 3 error.
    public class Toast : AnimControl
    {
        string msg = "";
        int kind;
        float t, hold;
        bool showing;
        public int BottomOffset = 24;
        Font f, gf;
        public Toast()
        {
            Visible = false;
            Height = 58;
            f = Theme.F(9.5f, FontStyle.Bold);
            gf = new Font(Theme.IconFont, 11f);
        }
        public void Pop(string message, int k)
        {
            msg = message ?? ""; kind = k;
            Width = Math.Min(520, Math.Max(260, TextRenderer.MeasureText(msg, f).Width + 84));
            hold = 2.4f; showing = true;
            if (!Visible) t = 0f;
            Visible = true; BringToFront(); Place(); Kick(); Invalidate();
        }
        void Place()
        {
            if (Parent == null) return;
            int baseLeft = Parent.ClientSize.Width - Width - 28;
            Left = baseLeft + (int)((1f - Gfx.Ease(t)) * (Width + 40));
            Top = Parent.ClientSize.Height - Height - BottomOffset;
        }
        protected override bool Step(float dt)
        {
            if (showing) { t = Math.Min(1f, t + 4.2f * dt); if (t >= 1f) { hold -= dt; if (hold <= 0) showing = false; } }
            else { t = Math.Max(0f, t - 5f * dt); if (t <= 0f) { Visible = false; return false; } }
            Place();
            return true;
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics; Gfx.Hq(g);
            RectangleF r = new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 7f);
            Gfx.SoftShadow(g, r, 14, Theme.AccentDeep, 6, 34);
            Color kc = kind == 1 ? Theme.Success : kind == 2 ? Theme.Warn : kind == 3 ? Theme.Danger : Theme.Accent;
            string glyph = kind == 1 ? "" : kind == 2 ? "" : kind == 3 ? "" : "";
            using (GraphicsPath p = Gfx.Round(r, 14))
            {
                using (SolidBrush b = new SolidBrush(Theme.Surface)) g.FillPath(b, p);
                using (Pen pen = new Pen(Theme.Border)) g.DrawPath(pen, p);
            }
            float cy = r.Y + r.Height / 2;
            using (SolidBrush cb = new SolidBrush(Gfx.A(kc, 34))) g.FillEllipse(cb, 14, cy - 15, 30, 30);
            TextRenderer.DrawText(g, glyph, gf, new Rectangle(14, (int)(cy - 15), 30, 30), kc,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            TextRenderer.DrawText(g, msg, f, new Rectangle(56, (int)r.Y, Width - 66, (int)r.Height), Theme.Text,
                TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine);
        }
    }
}
