﻿# =====================================================================
#  SETTING MP3 V1 - UI helpers (wrap the Mp3UI C# controls)
# =====================================================================

$script:Pages = [ordered]@{}
$script:PageHost = $null      # set by main: the area pages live in

function New-Font([float]$Size, [string]$Style = 'Regular') {
    New-Object System.Drawing.Font('Segoe UI', $Size, [System.Drawing.FontStyle]$Style)
}

function New-Page([string]$Key) {
    $sv = New-Object Mp3UI.ScrollView
    $script:PageHostPanel.AddPage($sv)
    $script:Pages[$Key] = $sv
    return $sv.Content
}

function New-PageTitle($Page, [string]$Title, [string]$Sub) {
    $t = New-Object System.Windows.Forms.Label
    $t.Text = $Title; $t.AutoSize = $true; $t.BackColor = 'Transparent'
    $t.Font = New-Font 20 'Bold'; $t.ForeColor = [Mp3UI.Theme]::Text
    $t.Location = New-Object System.Drawing.Point(4, 2)
    $Page.Controls.Add($t)
    $s = New-Object System.Windows.Forms.Label
    $s.Text = $Sub; $s.AutoSize = $true; $s.BackColor = 'Transparent'
    $s.Font = New-Font 9.75; $s.ForeColor = [Mp3UI.Theme]::Muted
    $s.Location = New-Object System.Drawing.Point(7, 42)
    $Page.Controls.Add($s)
}

function New-Card($Parent, [int]$X, [int]$Y, [int]$W, [int]$H, [string]$Title) {
    $c = New-Object Mp3UI.Card
    $c.Title = $Title
    $c.Bounds = New-Object System.Drawing.Rectangle($X, $Y, $W, $H)
    $Parent.Controls.Add($c)
    return $c
}

function New-Btn($Parent, [string]$Text, [int]$X, [int]$Y, [int]$W, [int]$H, [switch]$Accent, [switch]$Danger, [string]$Glyph) {
    $b = New-Object Mp3UI.ModernButton
    $b.Text = $Text; $b.Accent = [bool]$Accent; $b.Danger = [bool]$Danger
    if ($Glyph) { $b.Glyph = $Glyph }
    $b.Bounds = New-Object System.Drawing.Rectangle($X, $Y, $W, ($H + 6))   # +6 = shadow room
    $Parent.Controls.Add($b)
    return $b
}

function New-Lbl($Parent, [string]$Text, [int]$X, [int]$Y, [switch]$Muted, [switch]$Red, [switch]$Bold, [float]$Size = 9.25, [int]$MaxW = 0) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $Text; $l.AutoSize = $true; $l.BackColor = 'Transparent'
    $l.Font = New-Font $Size $(if ($Bold -or $Red) { 'Bold' } else { 'Regular' })
    $l.ForeColor = if ($Red) { [Mp3UI.Theme]::Danger } elseif ($Muted) { [Mp3UI.Theme]::Muted } else { [Mp3UI.Theme]::Text }
    $l.Location = New-Object System.Drawing.Point($X, $Y)
    $mw = if ($MaxW -gt 0) { $MaxW } else { [Math]::Max(60, $Parent.Width - $X - 18) }
    $l.MaximumSize = New-Object System.Drawing.Size($mw, 0)
    $l.UseMnemonic = $false
    $Parent.Controls.Add($l)
    return $l
}

# Segmented pill picker (modern replacement for ComboBox). $Labels = text shown, $Items = values returned.
function New-Combo($Parent, [string[]]$Items, [int]$X, [int]$Y, [int]$W, [string[]]$Labels) {
    $p = New-Object Mp3UI.SegmentedPicker
    $p.Items = $(if ($Labels) { $Labels } else { $Items })
    $p.Bounds = New-Object System.Drawing.Rectangle($X, $Y, $W, 40)
    $p.Tag = $Items
    $Parent.Controls.Add($p)
    return $p
}
function Get-ComboValue($Picker) { return $Picker.Tag[$Picker.SelectedIndex] }

# Wire a button to a named action (wait cursor + log + toast + status refresh)
function On-Click($Button, [string]$Name, [scriptblock]$Body, [string]$ConfirmMsg, [switch]$Danger) {
    $Button.Tag = @{ Name = $Name; Body = $Body; Confirm = $ConfirmMsg; Danger = [bool]$Danger }
    $Button.Add_Click({
        param($s)
        $t = $s.Tag
        if ($t.Confirm -and -not (Confirm-Action $t.Name $t.Confirm -Danger:$t.Danger)) { Log "$($t.Name) : ยกเลิก" 'warn'; return }
        Invoke-Action $t.Name $t.Body
    })
}

$script:CurrentPage = $null
function Show-Page([string]$Key) {
    $keys = @($script:Pages.Keys)
    $dir = if ($script:CurrentPage -and [array]::IndexOf($keys, $Key) -lt [array]::IndexOf($keys, $script:CurrentPage)) { -1 } else { 1 }
    $script:PageHostPanel.Navigate($script:Pages[$Key], $dir)
    $script:CurrentPage = $Key
    if ($script:Toast) { $script:Toast.BringToFront() }
}
