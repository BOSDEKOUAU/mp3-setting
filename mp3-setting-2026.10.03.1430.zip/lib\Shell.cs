// SETTING MP3 V1 - window shell: borderless form, title bar, sidebar, smooth scroll view, dialog
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Mp3UI
{
    internal static class Native
    {
        [DllImport("user32.dll")] public static extern bool ReleaseCapture();
        [DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr h, int msg, IntPtr w, IntPtr l);
        [DllImport("dwmapi.dll")] public static extern int DwmSetWindowAttribute(IntPtr h, int attr, ref int val, int size);
        public static void DragWindow(Form f)
        {
            if (f == null) return;
            ReleaseCapture();
            SendMessage(f.Handle, 0xA1, (IntPtr)2, IntPtr.Zero);
        }
    }

    public class ModernForm : Form, IAnimated
    {
        public bool FadeOut = true;
        enum Mode { None, Opening, Closing, Minimizing }
        Mode mode = Mode.None;
        float p;
        Point baseLoc;
        bool closeDone;
        FormWindowState lastState = FormWindowState.Normal;

        public ModernForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            DoubleBuffered = true;
            BackColor = Theme.Bg;
            StartPosition = FormStartPosition.CenterScreen;
            Opacity = 0;
        }

        void Begin(Mode m)
        {
            if (mode == Mode.None || mode == Mode.Opening) baseLoc = Location;
            mode = m; p = 0f;
            Animator.Start(this);
        }

        /// Fade + slide down, then minimize (restore plays the opening animation).
        public void AnimatedMinimize() { if (mode != Mode.Closing) Begin(Mode.Minimizing); }

        public bool Tick(float dt)
        {
            if (IsDisposed) return false;
            switch (mode)
            {
                case Mode.Opening:
                {
                    p = Math.Min(1f, p + dt / 0.38f);
                    float e = Gfx.EaseOutQuint(p);
                    Opacity = e;
                    Location = new Point(baseLoc.X, baseLoc.Y + (int)Math.Round((1f - e) * 18f));
                    if (p < 1f) return true;
                    Location = baseLoc; mode = Mode.None; return false;
                }
                case Mode.Closing:
                case Mode.Minimizing:
                {
                    bool min = mode == Mode.Minimizing;
                    p = Math.Min(1f, p + dt / (min ? 0.24f : 0.2f));
                    float e = Gfx.EaseInCubic(p);
                    Opacity = 1f - e;
                    Location = new Point(baseLoc.X, baseLoc.Y + (int)Math.Round(e * (min ? 28f : 14f)));
                    if (p < 1f) return true;
                    Opacity = 0;
                    mode = Mode.None;
                    if (min) { Location = baseLoc; WindowState = FormWindowState.Minimized; }
                    else { closeDone = true; BeginInvoke((MethodInvoker)delegate { Close(); }); }
                    return false;
                }
            }
            return false;
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= 0x20000;   // CS_DROPSHADOW
                cp.Style |= 0x20000;        // WS_MINIMIZEBOX (taskbar minimize/restore)
                return cp;
            }
        }
        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            try { int round = 2; Native.DwmSetWindowAttribute(Handle, 33, ref round, 4); } catch { } // Win11 rounded corners
        }
        protected override void OnShown(EventArgs e) { base.OnShown(e); Begin(Mode.Opening); }
        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            // restored from taskbar after an animated minimize -> play the opening animation
            if (lastState == FormWindowState.Minimized && WindowState == FormWindowState.Normal)
            {
                if (Opacity < 1.0) { mode = Mode.None; Begin(Mode.Opening); }
            }
            lastState = WindowState;
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (FadeOut && !closeDone && !e.Cancel && WindowState == FormWindowState.Normal)
            {
                e.Cancel = true;
                if (mode != Mode.Closing) Begin(Mode.Closing);
                return;
            }
            base.OnFormClosing(e);
        }
        protected override void OnActivated(EventArgs e) { base.OnActivated(e); foreach (Control c in Controls) if (c is TitleBar) c.Invalidate(); }
        protected override void OnDeactivate(EventArgs e) { base.OnDeactivate(e); foreach (Control c in Controls) if (c is TitleBar) c.Invalidate(); }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            using (Pen pen = new Pen(Color.FromArgb(200, 212, 235))) e.Graphics.DrawRectangle(pen, 0, 0, Width - 1, Height - 1);
        }
    }

    /// macOS-style title bar: traffic-light buttons (close / minimize / zoom-disabled),
    /// glyphs fade in when the group is hovered, window grays them out when inactive.
    public class TitleBar : AnimControl
    {
        public string Title = "SETTING MP3 V1";
        public string Caption = "FiveM Performance Tweaker";
        float groupHover;
        float[] press = new float[3];
        int hot = -1, down = -1;     // 0 close, 1 minimize, 2 zoom (disabled: fixed-size window)
        bool inGroup;
        Font tf, cf, lf;
        const float R = 7f, Gap = 22f, X0 = 22f;

        static readonly Color[] Fill = { Color.FromArgb(255, 95, 87), Color.FromArgb(254, 188, 46), Color.FromArgb(40, 200, 64) };
        static readonly Color[] Edge = { Color.FromArgb(224, 68, 62), Color.FromArgb(222, 161, 35), Color.FromArgb(29, 173, 43) };
        static readonly Color[] Ink  = { Color.FromArgb(120, 10, 6), Color.FromArgb(150, 87, 0), Color.FromArgb(10, 100, 20) };

        public TitleBar()
        {
            Dock = DockStyle.Top;
            Height = 46;
            BackColor = Theme.Surface;
            tf = Theme.F(9.5f, FontStyle.Bold);
            cf = Theme.F(8.5f, FontStyle.Regular);
            lf = new Font(Theme.IconFont, 9f);
        }
        PointF Center(int i) { return new PointF(X0 + i * Gap, Height / 2f); }
        int HitDot(Point pt)
        {
            for (int i = 0; i < 3; i++)
            {
                PointF c = Center(i);
                if (Math.Abs(pt.X - c.X) <= 10 && Math.Abs(pt.Y - c.Y) <= 12) return i;
            }
            return -1;
        }
        bool InGroup(Point pt) { return pt.X >= X0 - 14 && pt.X <= X0 + 2 * Gap + 14 && pt.Y >= 6 && pt.Y <= Height - 6; }
        bool FormActive { get { Form f = FindForm(); return f != null && Form.ActiveForm == f; } }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            int h = HitDot(e.Location);
            bool g = InGroup(e.Location);
            if (h != hot || g != inGroup) { hot = h; inGroup = g; Cursor = (h == 0 || h == 1) ? Cursors.Hand : Cursors.Default; Kick(); }
            base.OnMouseMove(e);
        }
        protected override void OnMouseLeave(EventArgs e) { hot = -1; inGroup = false; down = -1; Kick(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                if (hot >= 0 && hot < 2) { down = hot; Kick(); }
                else if (!inGroup) Native.DragWindow(FindForm());
            }
            base.OnMouseDown(e);
        }
        protected override void OnMouseUp(MouseEventArgs e)
        {
            int d = down; down = -1; Kick();
            ModernForm f = FindForm() as ModernForm;
            if (f != null && e.Button == MouseButtons.Left && d >= 0 && d == HitDot(e.Location))
            {
                if (d == 0) f.Close();
                else if (d == 1) f.AnimatedMinimize();
            }
            base.OnMouseUp(e);
        }
        protected override bool Step(float dt)
        {
            float gt = inGroup ? 1f : 0f;
            groupHover = Approach(groupHover, gt, 16f, dt);
            bool busy = groupHover != gt;
            for (int i = 0; i < 3; i++)
            {
                float t = down == i ? 1f : 0f;
                press[i] = Approach(press[i], t, 24f, dt);
                if (press[i] != t) busy = true;
            }
            return busy;
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics; Gfx.Hq(g);
            g.Clear(Theme.Surface);
            using (Pen pen = new Pen(Theme.Border)) g.DrawLine(pen, 0, Height - 1, Width, Height - 1);

            bool active = FormActive || groupHover > 0.01f;
            for (int i = 0; i < 3; i++)
            {
                PointF c = Center(i);
                bool disabled = i == 2;
                Color fill = (!active || disabled) ? Color.FromArgb(221, 223, 228) : Fill[i];
                Color edge = (!active || disabled) ? Color.FromArgb(205, 208, 214) : Edge[i];
                fill = Gfx.Lerp(fill, Color.Black, press[i] * 0.22f);
                using (SolidBrush b = new SolidBrush(fill)) g.FillEllipse(b, c.X - R, c.Y - R, R * 2, R * 2);
                using (Pen pen = new Pen(edge, 1f)) g.DrawEllipse(pen, c.X - R + 0.5f, c.Y - R + 0.5f, R * 2 - 1, R * 2 - 1);
                if (disabled || groupHover <= 0.01f) continue;
                using (Pen ink = new Pen(Gfx.A(Ink[i], (int)(230 * groupHover)), 1.35f))
                {
                    ink.StartCap = LineCap.Round; ink.EndCap = LineCap.Round;
                    float s = 2.9f;
                    if (i == 0) { g.DrawLine(ink, c.X - s, c.Y - s, c.X + s, c.Y + s); g.DrawLine(ink, c.X - s, c.Y + s, c.X + s, c.Y - s); }
                    else g.DrawLine(ink, c.X - s - 0.6f, c.Y, c.X + s + 0.6f, c.Y);
                }
            }

            // centered logo + title
            TextFormatFlags fl = TextFormatFlags.NoPrefix | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding;
            int tw = TextRenderer.MeasureText(g, Title, tf, Size.Empty, fl).Width;
            int total = 22 + 10 + tw;
            int x = (Width - total) / 2;
            RectangleF logo = new RectangleF(x, 12, 22, 22);
            using (GraphicsPath lp = Gfx.Round(logo, 7)) Gfx.Gradient(g, lp, logo, Theme.Accent, Theme.Accent2, 45f);
            TextRenderer.DrawText(g, "", lf, Rectangle.Round(logo), Color.White, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            TextRenderer.DrawText(g, Title, tf, new Rectangle(x + 32, 0, tw + 4, Height), Theme.Text, fl);

            int cw = TextRenderer.MeasureText(g, Caption, cf, Size.Empty, fl).Width;
            TextRenderer.DrawText(g, Caption, cf, new Rectangle(Width - cw - 22, 0, cw + 4, Height), Theme.Muted, fl);
        }
    }

    public class Sidebar : AnimControl
    {
        class Entry { public string Key, Text, Glyph; public float Hover; }
        List<Entry> items = new List<Entry>();
        int sel, hot = -1;
        Spring top = new Spring(), bot = new Spring();   // liquid pill: top edge / bottom edge (as item-top Y)
        public string Brand = "MP3 STEPLNW";
        public string BrandSub = "PERFORMANCE  •  BLUE EDITION";
        public string Footer = "Administrator";
        public string FooterSub = "v1.0  •  2026";
        public event EventHandler SelectionChanged;
        Font bf, bsf, sf, f, fb, gf, lg;
        const int Top0 = 150, ItemH = 48;

        public Sidebar()
        {
            Dock = DockStyle.Left;
            Width = 248;
            BackColor = Theme.Surface;
            bf = Theme.F(13f, FontStyle.Bold);
            bsf = Theme.F(7f, FontStyle.Bold);
            sf = Theme.F(7.5f, FontStyle.Bold);
            f = Theme.F(10f, FontStyle.Regular);
            fb = Theme.F(10f, FontStyle.Bold);
            gf = new Font(Theme.IconFont, 12f);
            lg = new Font(Theme.IconFont, 17f);
        }
        public void AddItem(string key, string text, string glyph)
        {
            Entry en = new Entry(); en.Key = key; en.Text = text; en.Glyph = glyph;
            items.Add(en);
            if (items.Count == 1) { top.Snap(ItemY(0)); bot.Snap(ItemY(0)); }
            Invalidate();
        }
        public string SelectedKey { get { return items.Count == 0 ? null : items[sel].Key; } }
        public void Select(string key)
        {
            for (int i = 0; i < items.Count; i++)
                if (items[i].Key == key)
                {
                    bool down = i > sel;
                    sel = i;
                    // leading edge snaps ahead, trailing edge follows softly -> stretch & settle
                    Spring lead = down ? bot : top, trail = down ? top : bot;
                    lead.Stiffness = 520f; lead.DampingRatio = 0.88f;
                    trail.Stiffness = 170f; trail.DampingRatio = 0.72f;
                    Kick();
                    if (SelectionChanged != null) SelectionChanged(this, EventArgs.Empty);
                    return;
                }
        }
        int ItemY(int i) { return Top0 + i * (ItemH + 4); }
        int Hit(Point p)
        {
            for (int i = 0; i < items.Count; i++)
                if (p.X >= 14 && p.X <= Width - 14 && p.Y >= ItemY(i) && p.Y < ItemY(i) + ItemH) return i;
            return -1;
        }
        protected override void OnMouseMove(MouseEventArgs e)
        {
            int h = Hit(e.Location);
            if (h != hot) { hot = h; Cursor = h >= 0 ? Cursors.Hand : Cursors.Default; Kick(); }
            base.OnMouseMove(e);
        }
        protected override void OnMouseLeave(EventArgs e) { hot = -1; Kick(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e)
        {
            int h = Hit(e.Location);
            if (h >= 0 && e.Button == MouseButtons.Left && h != sel) Select(items[h].Key);
            base.OnMouseDown(e);
        }
        protected override bool Step(float dt)
        {
            bool busy = false;
            float target = ItemY(sel);
            if (top.Step(target, dt)) busy = true;
            if (bot.Step(target, dt)) busy = true;
            for (int i = 0; i < items.Count; i++)
            {
                float t = i == hot ? 1f : 0f;
                items[i].Hover = Approach(items[i].Hover, t, 16f, dt);
                if (items[i].Hover != t) busy = true;
            }
            return busy;
        }
        void DrawItem(Graphics g, int i, Color c, TextFormatFlags vf)
        {
            int y = ItemY(i);
            float slide = i == sel ? 0f : items[i].Hover * 4f;   // hovered items nudge right
            Gfx.Label(g, items[i].Glyph, gf, new RectangleF(30 + slide, y + 1, 24, ItemH), c, true);
            Gfx.Label(g, items[i].Text, i == sel ? fb : f, new RectangleF(64 + slide, y, Width - 90, ItemH), c, false);
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics; Gfx.Hq(g);
            g.Clear(Theme.Surface);
            using (Pen p = new Pen(Theme.Border)) g.DrawLine(p, Width - 1, 0, Width - 1, Height);

            // brand
            RectangleF logo = new RectangleF(22, 30, 48, 48);
            Gfx.SoftShadow(g, logo, 15, Theme.Accent, 5, 50);
            using (GraphicsPath lp = Gfx.Round(logo, 15)) Gfx.Gradient(g, lp, logo, Theme.Accent, Theme.Accent2, 45f);
            TextFormatFlags c = TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding;
            TextRenderer.DrawText(g, "", lg, Rectangle.Round(logo), Color.White, c);
            TextFormatFlags fl = TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding;
            TextRenderer.DrawText(g, Brand, bf, new Point(80, 32), Theme.Text, fl);
            TextRenderer.DrawText(g, BrandSub, bsf, new Point(82, 60), Theme.Accent, fl);
            TextRenderer.DrawText(g, "MENU", sf, new Point(30, Top0 - 26), Color.FromArgb(148, 163, 184), fl);

            // hover backgrounds
            for (int i = 0; i < items.Count; i++)
                if (items[i].Hover > 0.01f && i != sel)
                {
                    RectangleF hr = new RectangleF(14, ItemY(i), Width - 28, ItemH);
                    using (GraphicsPath hp = Gfx.Round(hr, 13))
                    using (SolidBrush hb = new SolidBrush(Gfx.A(Theme.AccentSoft, (int)(255 * items[i].Hover)))) g.FillPath(hb, hp);
                }

            // pass 1: labels in normal color
            TextFormatFlags vf = TextFormatFlags.NoPrefix | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding | TextFormatFlags.SingleLine;
            for (int i = 0; i < items.Count; i++) DrawItem(g, i, Gfx.Lerp(Theme.Muted, Theme.Accent, items[i].Hover), vf);

            // pass 2: liquid pill + white labels clipped to it (color splits exactly at the pill edge)
            if (items.Count > 0)
            {
                float pt = Math.Min(top.X, bot.X), pb = Math.Max(top.X, bot.X) + ItemH;
                float squeeze = Math.Min(5f, (pb - pt - ItemH) * 0.05f);   // slimmer while stretched
                RectangleF ar = new RectangleF(14 + squeeze, pt, Width - 28 - squeeze * 2, pb - pt);
                Gfx.SoftShadow(g, ar, 13, Theme.Accent, 6, 60);
                using (GraphicsPath ap = Gfx.Round(ar, 13))
                {
                    Gfx.Gradient(g, ap, ar, Theme.Accent, Theme.Accent2, 20f);
                    Region old = g.Clip;
                    g.SetClip(ap, CombineMode.Intersect);
                    for (int i = 0; i < items.Count; i++) DrawItem(g, i, Color.White, vf);
                    g.Clip = old;
                }
            }

            // footer card
            RectangleF fr = new RectangleF(14, Height - 82, Width - 28, 62);
            using (GraphicsPath fp = Gfx.Round(fr, 14))
            {
                using (SolidBrush b = new SolidBrush(Theme.Surface2)) g.FillPath(b, fp);
                using (Pen p = new Pen(Theme.Border)) g.DrawPath(p, fp);
            }
            using (SolidBrush hb = new SolidBrush(Gfx.A(Theme.Success, 50))) g.FillEllipse(hb, fr.X + 16, fr.Y + 17, 14, 14);
            using (SolidBrush db = new SolidBrush(Theme.Success)) g.FillEllipse(db, fr.X + 19, fr.Y + 20, 8, 8);
            TextRenderer.DrawText(g, Footer, fb, new Point((int)fr.X + 40, (int)fr.Y + 12), Theme.Text, fl);
            TextRenderer.DrawText(g, FooterSub, sf, new Point((int)fr.X + 40, (int)fr.Y + 35), Theme.Muted, fl);
        }
    }

    public class BufferedPanel : Panel
    {
        public BufferedPanel()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
        }
    }

    /// Clips the pages and plays a vertical push transition: the new page glides in from
    /// below (or above when going up the menu) while the old one drifts away with parallax.
    public class PageHost : Panel, IAnimated
    {
        ScrollView cur, prev;
        float p = 1f;
        int dir = 1;
        public float Duration = 0.5f;
        public PageHost()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
            BackColor = Theme.Bg;
        }
        public void AddPage(ScrollView sv)
        {
            sv.Bounds = new Rectangle(0, 0, ClientSize.Width, ClientSize.Height);
            sv.Visible = false;
            Controls.Add(sv);
        }
        public void Navigate(ScrollView next, int direction)
        {
            if (next == null || next == cur) return;
            if (prev != null) { prev.Visible = false; prev.Top = 0; prev = null; }   // interrupted: finish instantly
            if (cur != null) cur.Top = 0;
            prev = cur; cur = next;
            dir = direction < 0 ? -1 : 1;
            cur.ScrollTo(0, false);
            if (prev == null) { cur.Top = 0; cur.Visible = true; cur.BringToFront(); p = 1f; return; }
            p = 0f;
            cur.Top = dir * Height;
            cur.Visible = true;
            cur.BringToFront();
            Animator.Start(this);
        }
        public bool Tick(float dt)
        {
            if (IsDisposed || cur == null) return false;
            p = Math.Min(1f, p + dt / Duration);
            float e = Gfx.EaseOutQuint(p);
            cur.Top = (int)Math.Round(dir * Height * (1f - e));
            if (prev != null) prev.Top = (int)Math.Round(-dir * Height * 0.25f * e);
            if (p < 1f) return true;
            if (prev != null) { prev.Visible = false; prev.Top = 0; prev = null; }
            cur.Top = 0;
            return false;
        }
    }

    /// Scroll container with eased wheel scrolling, drag-to-scroll with inertia,
    /// rubber-band overscroll, a slim custom scrollbar and a slide-in page transition.
    public class ScrollView : Control, IAnimated
    {
        public static List<ScrollView> All = new List<ScrollView>();
        public Panel Content;
        public int Gutter = 16;
        public float WheelStep = 120f;
        ScrollBarLite bar;
        float cur, target, vel, enterT = 1f;   // vel in px/second
        bool inertia, armed, dragging;
        int startY, lastY, lastTick;
        float startPos;

        public ScrollView()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
            BackColor = Theme.Bg;
            Content = new BufferedPanel();
            Content.BackColor = Theme.Bg;
            Controls.Add(Content);
            bar = new ScrollBarLite(this);
            Controls.Add(bar);
            bar.BringToFront();
            All.Add(this);
            WheelFilter.Ensure();
        }
        public float Position { get { return cur; } }
        public int MaxScroll { get { return Math.Max(0, Content.Height - Height); } }
        float Clamp(float v) { return Math.Max(0f, Math.Min(MaxScroll, v)); }
        void Kick() { Animator.Start(this); }

        public void UpdateExtent()
        {
            int bottom = 0;
            foreach (Control c in Content.Controls) bottom = Math.Max(bottom, c.Bottom);
            Content.Size = new Size(Math.Max(10, Width - Gutter), Math.Max(Height, bottom + 32));
            target = Clamp(target); cur = Clamp(cur);
            Apply();
        }
        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            if (bar != null) bar.Bounds = new Rectangle(Width - Gutter, 0, Gutter, Height);
            if (Content != null) UpdateExtent();
        }
        public void Wheel(int delta)
        {
            inertia = false;
            target = Clamp(target - delta / 120f * WheelStep);
            Kick();
        }
        public void ScrollTo(float pos, bool animate)
        {
            inertia = false;
            target = Clamp(pos);
            if (!animate) cur = target;
            Apply(); Kick();
        }
        public void PlayEnter() { enterT = 0f; Apply(); Kick(); }

        public bool Tick(float dt)
        {
            if (IsDisposed) return false;
            bool busy = false;
            if (inertia)
            {
                target += vel * dt;
                vel *= (float)Math.Exp(-4.2 * dt);            // friction
                if (target < 0 || target > MaxScroll) { target = Clamp(target); vel = 0; }
                if (Math.Abs(vel) < 12f) inertia = false; else busy = true;
            }
            if (!dragging)
            {
                float d = target - cur;
                if (Math.Abs(d) > 0.2f) { cur += d * (1f - (float)Math.Exp(-(inertia ? 40f : 11f) * dt)); busy = true; }
                else cur = target;
            }
            if (enterT < 1f) { enterT = Math.Min(1f, enterT + 3.4f * dt); busy = true; }
            Apply();
            return busy || dragging;
        }
        void Apply()
        {
            int y = -(int)Math.Round(cur);
            int x = (int)Math.Round((1f - Gfx.Ease(enterT)) * 40f);
            if (Content.Left != x || Content.Top != y) Content.Location = new Point(x, y);
            if (bar != null) bar.Invalidate();
        }

        // ---- drag to scroll ----
        public void EnableDrag(Control c)
        {
            if (c is ModernButton || c is TextBoxBase || c is ComboBox || c is SegmentedPicker || c is ModernTextBox || c is ScrollBarLite) return;
            c.MouseDown += DragDown; c.MouseMove += DragMove; c.MouseUp += DragUp;
            foreach (Control ch in c.Controls) EnableDrag(ch);
        }
        void DragDown(object s, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            armed = true; dragging = false; inertia = false;
            startY = lastY = Cursor.Position.Y; startPos = cur; target = cur; vel = 0;
            lastTick = Environment.TickCount;
        }
        void DragMove(object s, MouseEventArgs e)
        {
            if (!armed) return;
            int y = Cursor.Position.Y;
            if (!dragging && Math.Abs(y - startY) > 4) { dragging = true; Cursor.Current = Cursors.SizeNS; Kick(); }
            if (!dragging) return;
            float raw = startPos - (y - startY);
            if (raw < 0) raw *= 0.35f;
            else if (raw > MaxScroll) raw = MaxScroll + (raw - MaxScroll) * 0.35f;
            cur = target = raw;
            int now = Environment.TickCount, dt = Math.Max(1, now - lastTick);
            float inst = -(y - lastY) / (float)dt * 1000f;   // px/second
            vel = vel * 0.5f + inst * 0.5f;
            lastY = y; lastTick = now;
            Apply();
        }
        void DragUp(object s, MouseEventArgs e)
        {
            if (!armed) return;
            armed = false;
            if (!dragging) return;
            dragging = false;
            if (Environment.TickCount - lastTick > 90) vel = 0;
            if (cur < 0 || cur > MaxScroll) { target = Clamp(cur); inertia = false; }
            else inertia = Math.Abs(vel) > 60f;
            Kick();
        }
    }

    public class ScrollBarLite : Control, IAnimated
    {
        ScrollView owner;
        float hover;
        bool isHover, drag;
        int grabOffset;
        public ScrollBarLite(ScrollView o)
        {
            owner = o;
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Bg;
        }
        public bool Tick(float dt)
        {
            if (IsDisposed) return false;
            float tt = (isHover || drag) ? 1f : 0f;
            hover += (tt - hover) * (1f - (float)Math.Exp(-18f * dt));
            Invalidate();
            if (Math.Abs(tt - hover) < 0.01f) { hover = tt; return false; }
            return true;
        }
        void Kick() { Animator.Start(this); }
        RectangleF Thumb()
        {
            float h = Height, ch = owner.Content.Height;
            if (owner.MaxScroll <= 0 || ch <= 0) return RectangleF.Empty;
            float th = Math.Max(44f, h * h / ch);
            float p = Math.Max(0f, Math.Min(1f, owner.Position / owner.MaxScroll));
            float w = 5f + hover * 4f;
            return new RectangleF((Width - w) / 2f, 6 + p * (h - th - 12), w, th);
        }
        protected override void OnMouseEnter(EventArgs e) { isHover = true; Kick(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { isHover = false; Kick(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e)
        {
            RectangleF th = Thumb();
            if (th.IsEmpty) return;
            if (e.Y >= th.Y && e.Y <= th.Bottom) { drag = true; grabOffset = e.Y - (int)th.Y; }
            else owner.ScrollTo(owner.Position + (e.Y < th.Y ? -Height * 0.8f : Height * 0.8f), true);
            base.OnMouseDown(e);
        }
        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (drag)
            {
                RectangleF th = Thumb();
                float track = Height - th.Height - 12;
                if (track > 0) owner.ScrollTo((e.Y - grabOffset - 6) / track * owner.MaxScroll, false);
            }
            base.OnMouseMove(e);
        }
        protected override void OnMouseUp(MouseEventArgs e) { drag = false; Kick(); base.OnMouseUp(e); }
        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics; Gfx.Hq(g);
            g.Clear(Theme.Bg);
            RectangleF th = Thumb();
            if (th.IsEmpty) return;
            RectangleF track = new RectangleF(th.X, 6, th.Width, Height - 12);
            using (GraphicsPath tp = Gfx.Round(track, th.Width / 2))
            using (SolidBrush tb = new SolidBrush(Gfx.A(Theme.Border, (int)(120 + hover * 135)))) g.FillPath(tb, tp);
            using (GraphicsPath p = Gfx.Round(th, th.Width / 2))
                Gfx.Gradient(g, p, th, Gfx.Lerp(Color.FromArgb(147, 180, 245), Theme.Accent, hover), Gfx.Lerp(Color.FromArgb(147, 210, 245), Theme.Accent2, hover), 90f);
        }
    }

    /// Routes mouse wheel to the ScrollView under the cursor (no focus needed).
    public class WheelFilter : IMessageFilter
    {
        static bool installed;
        public static void Ensure() { if (installed) return; installed = true; Application.AddMessageFilter(new WheelFilter()); }
        public bool PreFilterMessage(ref Message m)
        {
            if (m.Msg != 0x020A) return false;
            Point p = Cursor.Position;
            foreach (ScrollView sv in ScrollView.All)
            {
                if (sv.IsDisposed || !sv.IsHandleCreated || !sv.Visible) continue;
                Form f = sv.FindForm();
                if (f == null || Form.ActiveForm != f) continue;
                if (sv.RectangleToScreen(sv.ClientRectangle).Contains(p))
                {
                    int delta = (short)((m.WParam.ToInt64() >> 16) & 0xFFFF);
                    sv.Wheel(delta);
                    return true;
                }
            }
            return false;
        }
    }

    public class ConfirmDialog : ModernForm
    {
        string title, msg;
        bool danger;
        Font tf, mf, gf;
        int msgH;

        public static bool Ask(IWin32Window owner, string title, string message, bool danger)
        {
            using (ConfirmDialog d = new ConfirmDialog(title, message, danger))
                return d.ShowDialog(owner) == DialogResult.Yes;
        }
        ConfirmDialog(string title, string message, bool danger)
        {
            this.title = title; msg = message; this.danger = danger;
            FadeOut = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Theme.Surface;
            KeyPreview = true;
            tf = Theme.F(12.5f, FontStyle.Bold);
            mf = Theme.F(9.75f, FontStyle.Regular);
            gf = new Font(Theme.IconFont, 16f);
            int w = 470;
            msgH = TextRenderer.MeasureText(msg, mf, new Size(w - 110, 2000), TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix).Height;
            ClientSize = new Size(w, Math.Max(200, 96 + msgH + 84));

            ModernButton yes = new ModernButton();
            yes.Text = danger ? "YES, CONTINUE" : "CONFIRM";
            yes.Accent = !danger; yes.Danger = danger;
            yes.Bounds = new Rectangle(w - 24 - 170, ClientSize.Height - 24 - 48, 170, 48);
            yes.Click += delegate { DialogResult = DialogResult.Yes; };
            ModernButton no = new ModernButton();
            no.Text = "CANCEL";
            no.Bounds = new Rectangle(w - 24 - 170 - 12 - 120, ClientSize.Height - 24 - 48, 120, 48);
            no.Click += delegate { DialogResult = DialogResult.No; };
            Controls.Add(yes); Controls.Add(no);
            yes.BackColor = Theme.Surface; no.BackColor = Theme.Surface;
        }
        protected override bool ProcessCmdKey(ref Message m, Keys k)
        {
            if (k == Keys.Escape) { DialogResult = DialogResult.No; return true; }
            if (k == Keys.Enter) { DialogResult = DialogResult.Yes; return true; }
            return base.ProcessCmdKey(ref m, k);
        }
        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) Native.DragWindow(this);
            base.OnMouseDown(e);
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics; Gfx.Hq(g);
            Color kc = danger ? Theme.Danger : Theme.Accent;
            RectangleF top = new RectangleF(0, 0, Width, 4);
            using (LinearGradientBrush lb = new LinearGradientBrush(new RectangleF(0, 0, Width + 1, 5), kc, danger ? Theme.Warn : Theme.Accent2, 0f)) g.FillRectangle(lb, top);
            RectangleF ic = new RectangleF(26, 30, 44, 44);
            using (SolidBrush b = new SolidBrush(Gfx.A(kc, 30))) g.FillEllipse(b, ic);
            TextRenderer.DrawText(g, danger ? "" : "", gf, Rectangle.Round(ic), kc, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            TextRenderer.DrawText(g, title, tf, new Point(84, 30), Theme.Text, TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding);
            TextRenderer.DrawText(g, msg, mf, new Rectangle(86, 62, Width - 110, msgH + 4), Theme.Muted, TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix);
            base.OnPaint(e);
        }
    }
}
