﻿# =====================================================================
#  SETTING MP3 V1  -  MP3 STEPLNW  |  FiveM Performance Tweaker
#  Run:  Run.bat   (or right-click > Run with PowerShell)
# =====================================================================
param([string]$Snapshot)   # -Snapshot <dir> : render every page to PNG and exit (UI preview, no tweaks applied)
$ErrorActionPreference = 'Stop'
$ScriptRoot = $PSScriptRoot

# ---------- elevate + STA ----------
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $Snapshot -and (-not $isAdmin -or [Threading.Thread]::CurrentThread.ApartmentState -ne 'STA')) {
    $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-STA', '-WindowStyle', 'Hidden', '-File', "`"$PSCommandPath`"")
    if ($isAdmin) { Start-Process powershell.exe -ArgumentList $argList -WindowStyle Hidden }
    else          { Start-Process powershell.exe -ArgumentList $argList -Verb RunAs -WindowStyle Hidden }
    exit
}

Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
[System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false)

try {
    # ---------- compile UI controls (cached DLL, rebuilt when .cs changes) ----------
    $csFiles = @("$ScriptRoot\lib\Controls.cs", "$ScriptRoot\lib\Shell.cs")
    $hash = (Get-FileHash -InputStream ([IO.MemoryStream]::new([Text.Encoding]::UTF8.GetBytes(
                (($csFiles | ForEach-Object { Get-Content $_ -Raw }) -join '')))) -Algorithm SHA1).Hash.Substring(0, 12)
    $dllDir = Join-Path $env:ProgramData "SettingMP3V1\bin"
    New-Item -ItemType Directory -Force -Path $dllDir | Out-Null
    $dll = Join-Path $dllDir "Mp3UI_$hash.dll"
    if (-not (Test-Path $dll)) {
        Get-ChildItem $dllDir -Filter 'Mp3UI_*.dll' -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
        Add-Type -Path $csFiles -ReferencedAssemblies System.Windows.Forms, System.Drawing -OutputAssembly $dll -OutputType Library
    }
    [void][Reflection.Assembly]::LoadFrom($dll)

    . "$ScriptRoot\lib\Core.ps1"
    . "$ScriptRoot\lib\Tweaks.ps1"
    . "$ScriptRoot\lib\Presets.ps1"
    . "$ScriptRoot\lib\UiKit.ps1"

    # ---------- window ----------
    $W = 1180; $H = 790
    $form = New-Object Mp3UI.ModernForm
    $form.Text = "SETTING MP3 V1"
    $form.ClientSize = New-Object System.Drawing.Size($W, $H)
    $script:Form = $form

    # app icon (gradient tile + note glyph)
    $bmp = New-Object System.Drawing.Bitmap 64, 64
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'; $g.TextRenderingHint = 'AntiAliasGridFit'
    $ir = New-Object System.Drawing.RectangleF(2, 2, 60, 60)
    $ib = New-Object System.Drawing.Drawing2D.LinearGradientBrush($ir, [Mp3UI.Theme]::Accent, [Mp3UI.Theme]::Accent2, 45)
    $g.FillPath($ib, [Mp3UI.Gfx]::Round($ir, 16))
    $sf = New-Object System.Drawing.StringFormat; $sf.Alignment = 'Center'; $sf.LineAlignment = 'Center'
    $g.DrawString([string][char]0xE8D6, (New-Object System.Drawing.Font('Segoe MDL2 Assets', 26)), [System.Drawing.Brushes]::White, $ir, $sf)
    $g.Dispose()
    $form.Icon = [System.Drawing.Icon]::FromHandle($bmp.GetHicon())

    $title = New-Object Mp3UI.TitleBar
    $title.Dock = 'None'
    $title.Bounds = New-Object System.Drawing.Rectangle(1, 1, ($W - 2), 46)
    $title.Title = "SETTING MP3 V1"

    $side = New-Object Mp3UI.Sidebar
    $side.Dock = 'None'
    $side.Bounds = New-Object System.Drawing.Rectangle(1, 47, 248, ($H - 48))
    foreach ($it in @(
        @('home',    'Dashboard',       0xE80F),
        @('cpu',     'CPU / Priority',  0xE945),
        @('input',   'Input',           0xE962),
        @('net',     'Network',         0xE774),
        @('power',   'Power / Timer',   0xE7E8),
        @('reg',     'Registry (.reg)', 0xE943),
        @('tools',   'Tools',           0xE90F),
        @('restore', 'Restore',         0xE777))) {
        $side.AddItem($it[0], $it[1], [string][char]$it[2])
    }
    $form.Controls.Add($title)
    $form.Controls.Add($side)

    # ---------- activity log ----------
    $logH = 150
    $logCard = New-Object Mp3UI.Card
    $logCard.Title = "ACTIVITY LOG"
    $logCard.Bounds = New-Object System.Drawing.Rectangle(270, ($H - $logH - 14), 888, $logH)
    $rb = New-Object System.Windows.Forms.RichTextBox
    $rb.BorderStyle = 'None'; $rb.ReadOnly = $true; $rb.BackColor = [Mp3UI.Theme]::Surface
    $rb.ForeColor = [Mp3UI.Theme]::Text; $rb.ScrollBars = 'Vertical'; $rb.DetectUrls = $false
    $rb.Font = New-Object System.Drawing.Font('Consolas', 9)
    $rb.Bounds = New-Object System.Drawing.Rectangle(22, 46, 846, ($logH - 62))
    $logCard.Controls.Add($rb)
    $bClear = New-Object Mp3UI.ModernButton
    $bClear.Text = "CLEAR"; $bClear.Glyph = [string][char]0xE74D
    $bClear.Bounds = New-Object System.Drawing.Rectangle(758, 8, 110, 38)
    $bClear.Add_Click({ $rb.Clear() })
    $logCard.Controls.Add($bClear)
    $form.Controls.Add($logCard)
    $script:LogBox = $rb

    $toast = New-Object Mp3UI.Toast
    $toast.BottomOffset = $logH + 26
    $form.Controls.Add($toast)
    $script:Toast = $toast

    # ---------- pages ----------
    $script:PageHostPanel = New-Object Mp3UI.PageHost
    $script:PageHostPanel.Bounds = New-Object System.Drawing.Rectangle(270, 62, ($W - 270 - 6), ($H - $logH - 14 - 62 - 8))
    $form.Controls.Add($script:PageHostPanel)
    . "$ScriptRoot\lib\Pages.ps1"
    foreach ($pg in $script:Pages.Values) { $pg.UpdateExtent(); $pg.EnableDrag($pg.Content) }

    $side.Add_SelectionChanged({ Show-Page $side.SelectedKey })
    Show-Page 'home'

    $form.Add_Shown({
        Log "Setting MP3 V1 ready  |  Administrator  |  Backup: $BackupDir" 'ok'
        Update-Status
    })

    if ($Snapshot) {
        New-Item -ItemType Directory -Force -Path $Snapshot | Out-Null
        # render off-screen so the preview never pops over (or gets clicked on) the desktop
        $form.StartPosition = 'Manual'; $form.Location = New-Object System.Drawing.Point(-6000, -6000); $form.ShowInTaskbar = $false
        $form.Show()
        $wait = { param($ms) $sw = [Diagnostics.Stopwatch]::StartNew(); while ($sw.ElapsedMilliseconds -lt $ms) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 10 } }
        & $wait 800
        Update-Status
        $shot = { param($name)
            $b = New-Object System.Drawing.Bitmap($form.Width, $form.Height)
            $form.DrawToBitmap($b, (New-Object System.Drawing.Rectangle(0, 0, $form.Width, $form.Height)))
            $b.Save((Join-Path $Snapshot "$name.png")); $b.Dispose() }
        foreach ($k in @($script:Pages.Keys)) { $side.Select($k); & $wait 900; & $shot $k }
        $side.Select('home'); & $wait 600
        $script:Pages['home'].ScrollTo(400, $false); & $wait 300; & $shot 'home_scrolled'
        $toast.Pop("SETTING MP3  -  สำเร็จ", 1); & $wait 700; & $shot 'toast'
        $side.Select('power'); & $wait 120; & $shot 'mid_page_push'
        $side.Select('cpu'); & $wait 900; $cbP.SelectedIndex = 5; & $wait 90; & $shot 'mid_picker'
        $form.FadeOut = $false; $form.Close()
        return
    }
    [System.Windows.Forms.Application]::Run($form)
}
catch {
    if ($Snapshot) { "ERROR: $($_.Exception.Message)`n$($_.InvocationInfo.PositionMessage)`n$($_.ScriptStackTrace)"; return }
    [System.Windows.Forms.MessageBox]::Show("เกิดข้อผิดพลาดตอนเปิดโปรแกรม:`n`n$($_.Exception.Message)`n`n$($_.InvocationInfo.PositionMessage)",
        "SETTING MP3 V1", 'OK', 'Error') | Out-Null
}
