﻿# =====================================================================
#  SETTING MP3 V1 - Core (paths, log, backup/restore engine, helpers)
# =====================================================================

$AppName    = "SETTING MP3 V1"
$AppDir     = Join-Path $env:ProgramData "SettingMP3V1"
$BackupDir  = Join-Path $AppDir "Backup"
$BackupFile = Join-Path $BackupDir "registry.json"
$StateFile  = Join-Path $BackupDir "state.json"
$LogFile    = Join-Path $AppDir "mp3.log"
New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null

$script:LogBox = $null   # RichTextBox (set by UI)
$script:Toast  = $null   # Mp3UI.Toast (set by UI)
$script:Form   = $null

# ---------- LOG ----------
function Log {
    param([string]$Msg, [ValidateSet('info','ok','warn','err')][string]$Level = 'info')
    $ts = (Get-Date).ToString("HH:mm:ss")
    try { Add-Content -Path $LogFile -Value "[$ts] [$Level] $Msg" -Encoding UTF8 } catch {}
    if ($script:LogBox) {
        $rb = $script:LogBox
        $col = switch ($Level) {
            'ok'   { [Mp3UI.Theme]::Success }
            'warn' { [Mp3UI.Theme]::Warn }
            'err'  { [Mp3UI.Theme]::Danger }
            default { [Mp3UI.Theme]::Text }
        }
        $rb.SelectionStart = $rb.TextLength; $rb.SelectionLength = 0
        $rb.SelectionColor = [Mp3UI.Theme]::Accent
        $rb.AppendText("[$ts]  ")
        $rb.SelectionColor = $col
        $rb.AppendText("$Msg`r`n")
        $rb.SelectionStart = $rb.TextLength
        $rb.ScrollToCaret()
        [System.Windows.Forms.Application]::DoEvents()
    }
}

function Toast([string]$Msg, [ValidateSet('info','ok','warn','err')][string]$Kind = 'ok') {
    $k = @{ info = 0; ok = 1; warn = 2; err = 3 }[$Kind]
    if ($script:Toast) { $script:Toast.Pop($Msg, $k) }
}

function Confirm-Action([string]$Title, [string]$Msg, [switch]$Danger) {
    return [Mp3UI.ConfirmDialog]::Ask($script:Form, $Title, $Msg, [bool]$Danger)
}

# Runs a long action with wait cursor + error handling + toast
function Invoke-Action([string]$Name, [scriptblock]$Body) {
    if ($script:Form) { $script:Form.Cursor = 'WaitCursor' }
    try {
        Log ">> $Name"
        & $Body
        Log "$Name : DONE" 'ok'
        Toast "$Name  -  สำเร็จ" 'ok'
    } catch {
        Log "$Name : ERROR - $($_.Exception.Message)" 'err'
        Toast "$Name  -  ผิดพลาด" 'err'
    } finally {
        if ($script:Form) { $script:Form.Cursor = 'Default' }
        if (Get-Command Update-Status -ErrorAction SilentlyContinue) { Update-Status }
    }
}

# Run a console command line, log failures (never throws, outputs nothing)
function Exec([string]$CmdLine, [switch]$Quiet) {
    $out = & cmd.exe /c "$CmdLine 2>&1"
    if ($LASTEXITCODE -ne 0 -and -not $Quiet) { Log "  ! $CmdLine  ->  $((@($out) -join ' ').Trim())" 'warn' }
}

# ---------- BACKUP STORE (value-level, first original wins) ----------
function Read-JsonTable([string]$Path) {
    $h = [ordered]@{}
    if (Test-Path $Path) {
        try {
            $obj = Get-Content $Path -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($p in $obj.PSObject.Properties) { $h[$p.Name] = $p.Value }
        } catch { }
    }
    return $h
}
$script:Bk    = Read-JsonTable $BackupFile
$script:State = Read-JsonTable $StateFile

function Save-Backup { $script:Bk    | ConvertTo-Json -Depth 5 | Set-Content -Path $BackupFile -Encoding UTF8 }
function Save-State  { $script:State | ConvertTo-Json -Depth 5 | Set-Content -Path $StateFile  -Encoding UTF8 }

function Backup-Core {
    # Kept for compatibility: the backup engine saves originals automatically per value.
    if (-not (Test-Path $BackupFile)) { Save-Backup }
}

# ---------- REGISTRY (64-bit view, with automatic backup) ----------
function Split-RegPath([string]$Path) {
    $Path = $Path -replace '^Registry::', '' -replace '^(HK\w+):', '$1'
    $i = $Path.IndexOf('\')
    $h = $Path.Substring(0, $i).ToUpper(); $sub = $Path.Substring($i + 1)
    $hive = switch ($h) {
        { $_ -in 'HKLM', 'HKEY_LOCAL_MACHINE' } { 'LocalMachine' }
        { $_ -in 'HKCU', 'HKEY_CURRENT_USER' }  { 'CurrentUser' }
        { $_ -in 'HKU',  'HKEY_USERS' }         { 'Users' }
        { $_ -in 'HKCR', 'HKEY_CLASSES_ROOT' }  { 'ClassesRoot' }
        default { throw "Unknown hive: $h" }
    }
    return @($hive, $sub)
}
function Open-RegKey([string]$Path, [switch]$Write, [switch]$Create) {
    $hive, $sub = Split-RegPath $Path
    $base = [Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]$hive, [Microsoft.Win32.RegistryView]::Registry64)
    if ($Create) { return $base.CreateSubKey($sub) }
    return $base.OpenSubKey($sub, [bool]$Write)
}
function Get-Reg([string]$Path, [string]$Name) {
    $k = Open-RegKey $Path
    if (-not $k) { return $null }
    try { return $k.GetValue($Name, $null) } finally { $k.Close() }
}
function Save-Original([string]$Path, [string]$Name) {
    $id = "$Path|$Name".ToLower()
    if ($script:Bk.Contains($id)) { return }
    $e = [ordered]@{ Path = $Path; Name = $Name; Existed = $false; Kind = $null; Value = $null }
    $k = Open-RegKey $Path
    if ($k) {
        if ($k.GetValueNames() -contains $Name) {
            $e.Existed = $true
            $e.Kind = $k.GetValueKind($Name).ToString()
            $v = $k.GetValue($Name, $null, 'DoNotExpandEnvironmentNames')
            if ($v -is [byte[]]) { $v = [Convert]::ToBase64String($v) }
            $e.Value = $v
        }
        $k.Close()
    }
    $script:Bk[$id] = $e
    Save-Backup
}
function ConvertTo-RegData($Value, [string]$Type) {
    switch ($Type) {
        'DWord'  { $u = [uint32]([int64]$Value -band 0xFFFFFFFFL); return [BitConverter]::ToInt32([BitConverter]::GetBytes($u), 0) }
        'QWord'  { return [int64]$Value }
        'Binary' { if ($Value -is [string]) { return [Convert]::FromBase64String($Value) } return [byte[]]$Value }
        'MultiString' { return [string[]]@($Value) }
        default  { return [string]$Value }
    }
}
function Set-Reg {
    param([string]$Path, [string]$Name, $Value, [ValidateSet('DWord','QWord','String','ExpandString','Binary','MultiString')][string]$Type = 'DWord')
    try {
        Save-Original $Path $Name
        $k = Open-RegKey $Path -Create
        $k.SetValue($Name, (ConvertTo-RegData $Value $Type), [Microsoft.Win32.RegistryValueKind]$Type)
        $k.Close()
    } catch { Log "  ! reg $Path\$Name : $($_.Exception.Message)" 'warn' }
}
function Remove-Reg([string]$Path, [string]$Name) {
    try {
        Save-Original $Path $Name
        $k = Open-RegKey $Path -Write
        if ($k) { $k.DeleteValue($Name, $false); $k.Close() }
    } catch { Log "  ! reg delete $Path\$Name : $($_.Exception.Message)" 'warn' }
}

function Restore-Registry {
    $n = 0
    foreach ($e in @($script:Bk.Values)) {
        try {
            if ($e.Existed) {
                $k = Open-RegKey $e.Path -Create
                $k.SetValue($e.Name, (ConvertTo-RegData $e.Value $e.Kind), [Microsoft.Win32.RegistryValueKind]$e.Kind)
                $k.Close()
            } else {
                $k = Open-RegKey $e.Path -Write
                if ($k) { $k.DeleteValue($e.Name, $false); $k.Close() }
            }
            $n++
        } catch { Log "  ! restore $($e.Path)\$($e.Name) : $($_.Exception.Message)" 'warn' }
    }
    if (Test-Path $BackupFile) {
        Move-Item $BackupFile (Join-Path $BackupDir ("registry.restored-{0}.json" -f (Get-Date -Format yyyyMMdd-HHmmss))) -Force
    }
    $script:Bk = [ordered]@{}
    Log "Registry restored: $n values"
}

# ---------- SYSTEM INFO ----------
function Get-SysInfo {
    $cpu = (Get-CimInstance Win32_Processor | Select-Object -First 1).Name.Trim()
    $gpus = @(Get-CimInstance Win32_VideoController | Select-Object -ExpandProperty Name)
    $real = @($gpus | Where-Object { $_ -notmatch 'Basic Display|Remote|Virtual|Parsec' })
    $gpu = if ($real.Count) { $real -join ' / ' } else { $gpus -join ' / ' }
    $ram = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)
    $os  = (Get-CimInstance Win32_OperatingSystem)
    [pscustomobject]@{ CPU = $cpu; GPU = $gpu; RAM = "$ram GB"; OS = "$($os.Caption -replace 'Microsoft ','') ($($os.BuildNumber))" }
}

function Get-HardwareID {
    if ($script:HWID) { return $script:HWID }
    $cpu = (Get-CimInstance Win32_Processor | Select-Object -First 1).ProcessorId
    $mb  = (Get-CimInstance Win32_BaseBoard | Select-Object -First 1).SerialNumber
    $uuid = (Get-CimInstance Win32_ComputerSystemProduct | Select-Object -First 1).UUID
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $bytes = $sha.ComputeHash([Text.Encoding]::UTF8.GetBytes("$cpu|$mb|$uuid"))
    $hex = -join ($bytes[0..9] | ForEach-Object { $_.ToString('X2') })
    $script:HWID = "MP3-" + ($hex -replace '(.{5})(?!$)', '$1-')
    return $script:HWID
}
